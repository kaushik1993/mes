<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:300px;width:800px;float:left;margin-top:100px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
		<form name="regi" method="post">
<div style="height:550px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">Department Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">department_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="department_id" style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">department_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="department"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:60px; width:800px; float:left;  margin-left:110px;">
		<div style="height:60px; width:150px; float:left;margin-top:25px; margin-left:40px; text-align: justify;">department_add :
		</div>
		<div style="height:60px; width:300px; float:left; margin-left: 10px;">
			<textarea  name="add" rows="3" cols="16" required></textarea>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">department_contect :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="departm"style="margin-left:25px;" required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:5px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into department(department_name,department_add,department_contect) values('".$_POST['department']."','".$_POST['add']."','".$_POST['departm']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:Department.php");
	
	mysqli_close($con);	
}
?>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>