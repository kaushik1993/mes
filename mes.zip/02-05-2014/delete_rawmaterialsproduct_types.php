<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from rawmaterialsproduct_types where raw_material_id=".$_REQUEST['raw_material_id'];
	if(mysqli_query($con,$str))
	{
		header ("location:rawmaterialsproduct_types.php");
	}
	
	?>
	