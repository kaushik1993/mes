<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from plant_department where plant_id='".$_REQUEST['plant_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:380px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">Update For plant_department</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">plant_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="plant" value="<?php echo $row['plant_id'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">plant_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="name" value="<?php echo $row['plant_name'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:80px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:88px; width:300px; float:left;">
			<textarea  name="add" rows="3" cols="17" value="<?php echo $row['Address'];?>" required style="height:70px; margin-top:2px;margin-left:70px;"></textarea>	
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">contact :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cont" value="<?php echo $row['contact'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="desc" value="<?php echo $row['description'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" value="<?php echo $row['creation_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:160px; float:left;text-align:justify;">machinary_information :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="machin" value="<?php echo $row['machinary_information'];?>" required style=" margin-left:-50px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:170px; margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update plant_department set plant_name='" . $_POST["name"] . "',Address='" . $_POST["add"] . "',Address='" . $_POST["add"] . "',contact='" . $_POST["cont"] . "',description='" . $_POST["desc"] . "',creation_date='" . $_POST["date"] ."',machinary_information='" . $_POST["machin"] . "'where plant_id='".$_POST["plant"]. "'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:plant_department.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>