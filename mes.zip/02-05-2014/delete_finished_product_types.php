
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from finished_product_types where type_id=".$_REQUEST['type_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:finished_product_types.php");
	}
	
	?>
