<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from emp_personal_information";
    $resulta = mysqli_query($con,$qry);
	$qry2="Select * from department";
    $resultb = mysqli_query($con,$qry2);
    
   
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:450px;width:800px;float:left;margin-top:70px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<div style="height:400px; width:800px;">
	<div style="height:50px; width:800px; float:left; float:left; background-repeat:repeat-x; background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">emp_official From</font>
	</div>
	<form name="regi" method="post">
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">emp_pid :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select> 
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">Designation :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="Designation" name="Designation" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">Department_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Department_id" name="Department_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['department_id'];
                    echo $ei;
                    echo '</option>';
                               
                }
                ?>
				</select> 
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">basesalary :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="basesalary" name="basesalary" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">ta :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="ta" name="ta" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">da :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="da" name="da" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">hra :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="hra" name="hra" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">pf :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="pf" name="pf" required/>
		</div>
	</div>
    <div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">grosssalary :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="grosssalary" name="grosssalary" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">joiningDate :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="joiningDate" name="joiningDate" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">workinghours :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="workinghours" name="workinghours" required/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit"/>
	<input type="reset" name="btnclear" value="Reset" />
</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into emp_official_information values(".$_POST['emp_pid'].",'".$_POST['Designation']."','".$_POST['Department_id']."','".$_POST['basesalary']."','".$_POST['ta']."','".$_POST['da']."','".$_POST['hra']."','".$_POST['pf']."','".$_POST['grosssalary']."','".$_POST['joiningDate']."','".$_POST['workinghours']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:emp_official_information.php");
	
	mysqli_close($con);	
}
?>
</form>

</div>
</div>
</div>
<?php		
include('footer.php');
?>