<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from customer";
    $result = mysqli_query($con,$qry);
    $qrya="Select * from supplier";
	$resulta = mysqli_query($con,$qrya);
    $qryb="Select * from emp_personal_information";
	$resultb = mysqli_query($con,$qryb);
    
   
?>

				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:450px;width:800px;float:left;margin-top:70px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:50px;  width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white; color:#FFFFFF;">salesorders Form</font>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px; margin-top:2px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">sales_id :
			</div>
			<div style="height:25px; width:300px;float:left;">
				<input type="text" id="text" name="sal" style="margin-left:50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">customer_id :	
			</div>
			<div style="height:25px; width:300px; float:left;">
				<select id="customer_id" name="customer_id">
                 <?php
                while($row100=mysqli_fetch_array($result))
                {
                    echo '<option>';
                    $ei = $row100['customer_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
			</div>
		</div>
		
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:150px; float:left;text-align:justify;">Date_of_sales :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<input type="date" id="text" name="da" style="margin-left:-50px;" required/>
			</div>
		</div>
	
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:150px; float:left; text-align:justify;">Customer_Reference :
			</div>
			  <div style="height:25px; width:300px; float:left;">
				<input type="text" id="text" name="custo"style="margin-left:-50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:150px; float:left;text-align:justify;">paymentermes :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<input type="text" id="text" name="paym" style="margin-left:-50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:150px; float:left;text-align:justify;">no_of_product :
			</div>
			<div style="height:25px; width:300px; float:left; margin-left:-50px;">
				<select id="no_of_product" name="no_of_product">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option></select>
			</div>
		</div>

		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">invoice_lines :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<input type="text" id="text" name="inv" style="margin-left:50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">salesperson :	
			</div>
			<div style="height:25px; width:300px; float:left;">
			 <select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>	
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<input type="text" id="text" name="pay" style="margin-left:50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<input type="date" id="text" name="due" style="margin-left:50px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:160px; float:left;text-align:justify;">ordertype_custsupplyer :		
			</div>
			<div style="height:25px; width:250px; float:left;">
				<input type="text" id="text" name="ord" style="margin-left:-20px;" required/>
			</div>
		</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
			<div style="height:25px; width:100px; float:left;text-align:justify;">supplier_id :
			</div>
			<div style="height:25px; width:300px; float:left;">
				<select id="supplier_id" name="supplier_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['Supplier_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
			</div>
		</div>
	
		<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
		<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	

	$sql = "insert into
salesorders(customer_id,Date_of_sales,Customer_Reference,paymentermes,invoice_lines,salesperson,payment_type,due_date,ordertype_custsupplyer,supplier_id) values(".$_POST['customer_id'].",'".$_POST['da']."','".$_POST['custo']."','".$_POST['paym']."','".$_POST['sales']."','".$_POST['inv']."','".$_POST['emp_pid']."','".$_POST['due']."','".$_POST['ord']."',".$_POST['supplier_id'].")";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	 
	 $sql = "select * from salesorders order by sales_id DESC";
	 $result = mysqli_query($con,$sql);
	 $row = mysqli_fetch_array($result);
	 $a = $row['sales_id'];
	header("location:sales_particular.php?no_of_product=".$_POST['no_of_product']."&sales_id=".$a);
	mysqli_close($con);	
}
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>