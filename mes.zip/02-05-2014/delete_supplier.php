<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from supplier where Supplier_id=".$_REQUEST['Supplier_id'];
	if(mysqli_query($con,$str))
	{
		header ("location:supplier.php");
	}
	
	?>
	
	