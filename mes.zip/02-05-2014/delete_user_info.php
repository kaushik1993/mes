<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from user_info where emp_pid=".$_REQUEST['emp_pid'];
	if(mysqli_query($con,$str))
	{
		header ("location:user_info.php");
	}
	
	?>
	