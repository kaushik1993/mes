<?php
include('head.php');
include('sidemenu.php');
?>				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from department where department_id='".$_REQUEST['department_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:240px; width:700px;">
	<div style="height:50px; width:700px;float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:80px;">Update For Department</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left; text-align:justify;">department_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="depart" value="<?php echo $row['department_id'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:130px; float:left;text-align:justify;">department_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="department" value="<?php echo $row['department_name'];?>" required style="margin-left:-15px;"/>
		</div>
	</div>
	<div style="height:80px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left;margin-top:25px;text-align:justify;">department_add :
		</div>
		<div style="height:88px; width:300px; float:left;">
			<textarea  name="add" rows="3" cols="17" value="<?php echo $row['department_add'];?>" required style="height:70px;margin-top:2px;margin-left:10px;"></textarea>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:140px; float:left;text-align:justify;">department_contect :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="departm" value="<?php echo $row['department_contect'];?>" required style="margin-left:-35px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update department set department_name='" . $_POST["department"] . "',department_add='" . $_POST["add"] . "',department_contect='" . $_POST["departm"] .
	 "' where department_id='".$_POST["depart"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:Department.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>