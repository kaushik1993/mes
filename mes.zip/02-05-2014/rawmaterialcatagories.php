<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:400px;width:730px;float:left;margin-top:100px;margin-left:30px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<div style="height:30px; width:730px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" color="white">All rawmaterialcatagories information</font>
                    <a href="I_rawmaterialcatagories.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from rawmaterialcatagories";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:730px;float:left;">';
	echo'<div style="height:20px; width:730px;  color:white;;">
		<div style="height:20px; width:90px; float:left; background:#00458f;">Category_id
		</div>
		<div style="height:20px; width:210px; float:left; background:#00458f;">raw_materials_product_type_id
		</div>
		<div style="height:20px; width:120px; float:left; background:#00458f;">Category_name
		</div>
		<div style="height:20px; width:100px; float:left; background:#00458f;">creation_date
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">DELETE
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">UPDATE
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">VIEW
		</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:730px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:730px; background:silver;">';
			$cnt=0;
		}
	
		echo'<div style="height:20px; width:90px; float:left;">'.$arr['Category_id'].'
				</div>
				<div style="height:20px; width:210px; float:left;">'.$arr['raw_materials_product_type_id'].'
				</div>
				<div style="height:20px; width:120px; float:left;">'.$arr['Category_name'].'
				</div>
				<div style="height:20px; width:100px; float:left;">'.$arr['creation_date'].'
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="delete_rawmaterialcatagories.php?Category_id='.$arr['Category_id'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="update_rawmaterialcatagories1.php?Category_id='.$arr['Category_id'].'"><img src="images/update.png"/></a></div>
				<div style="height:20px; width:70px; float:left;"><a href="view_rawmaterialcatagories1.php?Category_id='.$arr['Category_id'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>