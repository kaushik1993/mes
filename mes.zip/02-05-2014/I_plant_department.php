<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:370px;width:800px;float:left;margin-top:105px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
<form name="regi" method="post">
<div style="height:320px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">plant_department From</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Plant_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="plant" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">plant_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="name" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:80px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:88px; width:300px; float:left;margin-top:3px; margin-left:35px;">
				<textarea  name="add" rows="4" cols="17" required></textarea>	
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">contact :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cont" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="desc" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:200px; float:left;text-align:justify;">machinary_information :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="machin" style=" margin-left:-130px;"required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into plant_department values('".$_POST['plant']."','".$_POST['name']."','".$_POST['add']."','".$_POST['cont']."','".$_POST['desc']."','".$_POST['date']."','".$_POST['machin']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:plant_department.php");
	
	mysqli_close($con);	
}
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>