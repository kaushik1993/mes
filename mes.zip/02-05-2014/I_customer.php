<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
    
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from emp_personal_information";
	$result = mysqli_query($con,$qry);
	$qrya="Select * from supplier";
	$resulta = mysqli_query($con,$qrya);

?>

		<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<form name="regi" method="post">
<div style="height:505px; width:800px;">
	<div style="height:30px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">Customer Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">customer_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="custom" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Nameofcompany :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Nameofcom" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Nameofcust :
		</div>
		<div style="height:25px; width:300px; float:left; ">
			<input type="text" id="text" name="Nameofcu" required/>
		</div>
	</div>
	<div style="height:60px; width:800px; float:left;  margin-left:150px;">
		<div style="height:60px; width:150px; float:left;margin-top:25px;text-align: justify;">Address :
		</div>
		<div style="height:60px; width:300px; float:left;margin-top:2px;">
			<textarea  name="add" rows="3" cols="17"></textarea>
			
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">City :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cit" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat" required/>
		</div>
	</div>
	
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">country :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="countr" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Website :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Webs" required/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">jobpositions :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="jobpos" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Mobile :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Mobil" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="mail" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Salesperson :
		</div>
		<div style="height:25px; width:300px; float:left;">
		      <select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($result))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>   
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Supplier :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Supplier_id" name="Supplier_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['Supplier_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">reference :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="refer" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Active :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Activ" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Language :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Lang" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:190px; float:left;text-align: justify;">ReceiveMessagesBye_mail :
		</div>
		<div style="height:25px; width:220px; float:left;">
			<input type="text" id="text" name="receive" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">registereddate :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">opt_out :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="optut"required/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style=" margin-left:150px;margin-top:5px;" />
	<input type="reset" name="btnclear" value="Reset" />
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into customer(Nameofcompany,Nameofcust,Address,City,State,country,Website,jobpositions,Mobile,E_mail,Salesperson,Supplier,reference,Active,Language,ReceiveMessagesBye_mail,registereddate,opt_out) values('".$_POST['Nameofcom']."','".$_POST['Nameofcu']."','".$_POST['add']."','".$_POST['cit']."','".$_POST['stat']."','".$_POST['countr']."','".$_POST['Webs']."','".$_POST['jobpos']."','".$_POST['Mobil']."','".$_POST['mail']."','".$_POST['emp_pid']."','".$_POST['Supplier_id']."','".$_POST['refer']."','".$_POST['Activ']."','".$_POST['Lang']."','".$_POST['receive']."','".$_POST['date']."','".$_POST['optut']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:Customer.php");
	
	mysqli_close($con);	
}
?>	

</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>