<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
    
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from customer";
    $result = mysqli_query($con,$qry);
	$qrya="Select * from emp_personal_information";	
	$resulta = mysqli_query($con,$qrya);	
    $resultb = mysqli_query($con,$qrya);
      
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:450px;width:800px;float:left;margin-top:50px;margin-left:100px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
		<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:30px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">salesreturn_orders Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px; margin-top:2px;">
		<div style="height:25px; width:160px; float:left;text-align:justify;">Sales_return_order_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="sal" style="margin-left:-60px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">customer_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="customer_id" name="customer_id">
                 <?php
                while($row100=mysqli_fetch_array($result))
                {
                    echo '<option>';
                    $ei = $row100['customer_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">employee_id :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="employee_id" name="employee_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Customer :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cust" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:160px; float:left;text-align:justify;">sales Date_return date :	
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="date" id="text" name="sle"style="margin-left:-20px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">Customer_Reference :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="custo"style="margin-left:-50px;" required/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">paymentermes :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="paym" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">invoice_lines :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="inv" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">salesperson :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="employee_id" name="employee_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>

		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pay" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">coustmer_reference :
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="cou" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="due" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:160px; float:left;text-align:justify;">ordertype_custsupplyer :	
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="ord"style="margin-left:-20px;" required/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>

<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into salesreturn_orders values(0,".$_POST['customer_id'].",".$_POST['employee_id'].",'".$_POST['cust']."','".$_POST['sle']."','".$_POST['custo']."','".$_POST['paym']."','".$_POST['inv']."','".$_POST['employee_id']."','".$_POST['pay']."','".$_POST['cou']."','".$_POST['due']."','".$_POST['ord']."')";
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:salesreturn_orders.php");
	
	mysqli_close($con);	
}
?>	
</div>
</div>
</div>
<?php		
include('footer.php');
?>