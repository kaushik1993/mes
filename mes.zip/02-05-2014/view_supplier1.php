<?php
include('head.php');
include('sidemenu.php');		

?>
				
				<div id="block30" class="overview1"><a href="supplier.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:50px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from supplier where Supplier_id='".$_REQUEST['Supplier_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:500px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">View For Supplier</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Supplier_id
		</div>
		<div style="height:25px; width:300px;float:left;">
			<?php echo $row['Supplier_id'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Product_Name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Product_Name'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Name_company	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Name_company'];?>
		</div>
	</div>
	<div style="height:80px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address
		</div>
		<div style="height:88px; width:300px; float:left; margin-top:5px;">
			<?php echo $row['Address'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">City
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['City'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['State'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Website
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Website'];?>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">jobpositions
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['jobpositions'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Mobile
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Mobile'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Fax
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Fax'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['E_mail'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">title
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['title'];?>
		</div>
	</div>

</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>