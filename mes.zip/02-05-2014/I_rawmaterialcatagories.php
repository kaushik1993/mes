<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from finished_product_types";
    $result = mysqli_query($con,$qry);
    
   
?>

				
			<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:800px;float:left;margin-top:70px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<form name="regi" method="post">
<div style="height:210px; width:800px;">
	<div style="height:50px; width:800px;float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">rawmaterialcatagories Form</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Category_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="cat" style="margin-left:100px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;">
		<div style="height:25px; width:250px; float:left;margin-left:150px;text-align:justify;">raw_materials_product_type_id :	
		</div>
		<div style="height:25px; width:30px; float:left;">
				<select id="raw_materials_product_type_id" name="raw_materials_product_type_id">
                 <?php
                while($row100=mysqli_fetch_array($result))
                {
                    echo '<option>';
                    $ei = $row100['type_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">Category_name :
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="cate" style="margin-left:50px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="crea" style="margin-left:100px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="des" style="margin-left:100px;" required/>
		</div>
	</div>
	

	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>

<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into rawmaterialcatagories(raw_materials_product_type_id,Category_name,creation_date,Description)values('".$_POST['raw_materials_product_type_id']."','".$_POST['cate']."','".$_POST['crea']."','".$_POST['des']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:rawmaterialcatagories.php");
	
	mysqli_close($con);	
}
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>