<?php 
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
 	$sql = "select * from salesorders where sales_id=".$_REQUEST['sales_id'];
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);
    $a = $row['sales_id'];
	$b = $row['customer_id'];
	$h = $row['due_date'];
	$sql1 = "select * from customer where customer_id=".$b;
	$result1 = mysqli_query($con,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$c = $row1['Nameofcompany'];
	$d = $row1['Nameofcust'];
	$e = $row1['Address'];
	$f = $row1['City'];
	$g = $row1['Mobile'];
	$sqla = "select * from sales_particular where sales_id=".$a;
	$resulta = mysqli_query($con,$sqla);
	$resultb=mysqli_query($con,$sqla);
	$resultc=mysqli_query($con,$sqla);
	$resultd=mysqli_query($con,$sqla);
	$resulte=mysqli_query($con,$sqla);
    	
 	$sql10 = "select * from form ";
	$result11 = mysqli_query($con,$sql10);
	$row4 = mysqli_fetch_array($result11);
    $com = $row4['companyname'];
    $add = $row4['address'];
    $cont = $row4['contactno'];
    $tnl = $row4['tnl_stno'];
    $tnl1 = $row4['tnl_ctno'];
    $term = $row4['terms_condition1'];
    $term1 = $row4['terms_condition2'];
    $term2 = $row4['terms_condition3'];
    $term3 = $row4['terms_condition4'];
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<center>
	<div style="width:700px; height:800px; float:left; border:ridge;">
		<div style="width:700px; height:100px; float:left; border-bottom:ridge;">
			<div style="width:197px; height:100px; float:left; border-right:ridge;">
				<img src="images/social_stumbleupon_box_white.png" height="100px" width="197px">
			</div>
			<div style="width:500px; height:100px; float:left;">
            <?php
            echo $com."</br>".$add."</br>".$cont;
            ?>
			</div>
		</div>
		<div style="width:700px; height:30px; float:left; border-bottom:ridge;">
		INVOICE
		</div>
		<div style="width:700px; height:150px; float:left; border-bottom:ridge;">
			<div style="width:247px; height:150px; float:left; border-right:ridge; text-align:left;">
			<font size="+1">customer id:-<?php echo $b."</br>name of company:-".$row1['Nameofcompany']."</br>Nameofcust:-".$row1['Nameofcust']."</br>Address:-".$row1['Address']."</br>City:-". $row1['City']."<br>Mobile:-".$row1['Mobile'];?></font>
			</div>
			<div style="width:450px; height:150px; float:left;">
				<div style="width:225px; height:150px; float:left;">
					invoice no:<?php echo $a;?> <br><br> D.H/NO.3009
				</div>
				<div style="width:225px; height:150px; float:left;">
				<?php echo date("d-m-y")."</br></br>".$h;?>
				</div>
			</div>
		</div>
		<div style="width:700px; height:30px; float:left; border-bottom:ridge;">
			<div style="width:297px; height:30px; float:left; border-right:ridge;">
			Description
			</div>
			<div style="width:147px; height:30px; float:left;  border-right:ridge;">
			Quantity
			</div>
			<div style="width:97px; height:30px; float:left;  border-right:ridge;">
			Rate
			</div>
			<div style="width:147px; height:30px; float:left;">
			Amount</b>
			</div>
		</div>
		<div style="width:700px; height:270px; float:left; border-bottom:ridge;">
			<div style="width:297px; height:270px; float:left; border-right:ridge;">
			<?php
			 	while($row90=mysqli_fetch_array($resulta))
					{
					   
					echo'<div style="width:297px; height:20px; float:left; border-right:ridge;">';
						$qr1 = "select * from finished_product where pro_id=1";
                        $res1 = mysqli_query($con,$qr1);
                        $r1 = mysqli_fetch_array($res1);
						$i = $r1['description'];
						echo $i;
					echo'</div>';
					} 
			?>
			</div>
			<div style="width:147px; height:270px; float:left;  border-right:ridge;">
			<?php
			
				while($row4=mysqli_fetch_array($resultb))
					{
						echo'<div style="width:147px; height:20px; float:left;  border-right:ridge;">';
						$j = $row4['quantity'];
						echo $j;
						echo'</div>';
					} 
			?>
			</div>
			<div style="width:97px; height:270px; float:left;  border-right:ridge;">
			<?php
				reset($resultc);
			 	while($row5=mysqli_fetch_array($resultc))
					{
						echo'<div style="width:97px; height:20px; float:left;  border-right:ridge;">';
						$k = $row5['rate'];
						echo $k;
						echo'</div>';
					} 
			?>
			</div>
			<div style="width:147px; height:270px; float:left;">
			<?php
			reset($resultd);
            $sum = 0;
				while($row6=mysqli_fetch_array($resultd))
					{
						echo'<div style="width:147px; height:20px; float:left;">';
						$l = $row6['amount'];
						echo $l;
                        $sum = $sum + $l;   
						echo'</div>';
                        
					} 
			?>
			</div>
		</div>
		<div style="width:700px; height:30px; float:left; border-bottom:ridge;">
			<div style="width:100px; height:30px; float:left; ">
			 <b>RS :
			</div>
			<div style="width:450px; height:30px; float:left;">
            <?php

            function convert_number($number) 
            { 
            if (($number < 0) || ($number > 999999999)) 
            { 
            throw new Exception("Number is out of range");
            } 
    $Gn = floor($number / 1000000); 
    $number -= $Gn * 1000000; 
    $kn = floor($number / 1000);      
    $number -= $kn * 1000; 
    $Hn = floor($number / 100);    
    $number -= $Hn * 100; 
    $Dn = floor($number / 10);       
    $n = $number % 10;            
    $res = ""; 
    if ($Gn) 
    { 
        $res .= convert_number($Gn) . " Million"; 
    } 

    if ($kn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($kn) . " Thousand"; 
    } 
    if ($Hn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($Hn) . " Hundred"; 
    } 
    $ones = array("", "One", "Two", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", 
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", 
        "Nineteen"); 
    $tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", 
        "Seventy", "Eigthy", "Ninety"); 
    if ($Dn || $n) 
    { 
        if (!empty($res)) 
        { 
            $res .= " and "; 
        } 

        if ($Dn < 2) 
        { 
            $res .= $ones[$Dn * 10 + $n]; 
        } 
        else 
        { 
            $res .= $tens[$Dn]; 

            if ($n) 
            { 
                $res .= "-" . $ones[$n]; 
            } 
        } 
    } 
    if (empty($res)) 
    { 
        $res = "zero"; 
    } 
    return $res; 
    } 
    $cheque_amt = $sum ; 
    try
    {
    echo convert_number($cheque_amt);
    }
    catch(Exception $e)
    {
    echo $e->getMessage();
    }
            ?>
           	</div>
			<div style="width:147px; height:30px; float:left;">
		    <?php 
		       	reset($resulte);
				$row7=mysqli_fetch_array($resulte);
                echo'<div style="width:147px; height:30px; float:left;">';  
                echo $sum;
            ?>
			</b>
			</div>
		</div>
		<div style="width:700px; height:174px; float:left;">
			<div style="width:347px; height:174px; float:left;  border-right:ridge;">
			<div style="width:350px; height:124px; float:left;">
				 <?php
                     echo $tnl."</br>".$tnl1;
                 ?>
				</div>
				<div style="width:350px; height:50px; float:left;"><b>CUSTOMER SIGNATURE:</b><br>S.D.Hirapara
				</div>
			</div>
			<div style="width:350px; height:174px; float:left;">
				<div style="width:350px; height:124px; float:left;">
                 <?php
                     echo $term."</br>".$term1."</br>".$term2."</br>".$term3;
                 ?>
				</div>
				<div style="width:350px; height:50px; float:left;"><b>NAME OF COMPANY:</b><br>manufacturing execution system
				</div>
			</div>
		</div>
	</div>
</center>
</body>
</html>
