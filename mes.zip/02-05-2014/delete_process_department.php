
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from process_department where process_id=".$_REQUEST['process_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:process_department.php");
	}
	
	?>
