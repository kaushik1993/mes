<?php 
  	include('head.php');
	include('sidemenu.php');
?>
<script type="text/javascript" language="javascript">	
function pwd1(){	
	if(upd_customer.New_Password.value!=upd_customer.Re-enter_New_Password.value)
	{
		alert("password do not match");
		return false;			
	}
alert("111111111111111111111");
}
</script>

<?php									
	
	if($_SESSION['user_name']=="" or $_SESSION['password']=="")
	{
		header("location:user_info.php");
	}
	
	
	if(isset($_POST['sbt']))
	{
	   if($_POST['Old_Password']==$_SESSION['password'] && $_POST['New_Password'] == $_POST['Re-enter_New_Password'])
       {   	
		$conn=mysqli_connect("localhost","root","","mes") or die("unable to connect");
		
		$str="update user_mgt set password='".$_POST['Re-enter_New_Password']."' where emp_pid='".$_SESSION['emp_pid']."'";
	   	
           echo $str;
           
           if(mysqli_query($conn,$str))
            echo "ok";   
		else	
			echo "Error : ".mysqli_error();
	
    	mysqli_close($conn);
    }
    else
    {
        echo "<span style='color:red;'>Please enter your password properly</span>";
    }
		

	}
	
?>
<form name="upd_customer" method="post">
<article id="wrapper_cont" class="wrapper">
		<section id="insert_form" class="insert_form" >
			<div id="form_header" class="form_header">
				<section id="form_text" class="form_text"><div style="margin-top:4px;">Change Password</div></section>
			</div>
			<div id="form_details" class="form_details">
				<section id="form_details_1" class="form_details_1">
					<div id="lable" class="lable">
					<div style="margin-right:40px;">Old_Password :</div></div>
					<div id="textbox" class="textbox">
						<input type="password" name="Old_Password" id="Old_Password" style="placeholder="password"/>
					</div>
				</section>
				<section id="form_details_1" class="form_details_1">
					<div id="lable" class="lable"><div style="margin-right:40px;">New_Password :</div></div>
					<div id="textbox" class="textbox">
						<input type="password" name="New_Password" id="New_Password" required/>
					</div>
				</section>
                <section id="form_details_1" class="form_details_1">
					<div id="lable" class="lable"><div style="margin-right:40px;">Re-enter_New_Password :</div></div>
					<div id="textbox" class="textbox">
						<input type="password" name="Re-enter_New_Password" id="Re-enter_New_Password" required/>
					</div>
				</section>
                <section id="form_details_1" class="form_details_1">
						<p style="margin-top:40px;"><input type="submit" onclick="return pwd1(this.upd_customer);" name="submit" id="submit" /></p>
				</section>
			</div>
		</section>
	</article>
</form>
<?php
    include('footer.php');
?>
