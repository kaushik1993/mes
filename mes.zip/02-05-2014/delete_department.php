
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from department where department_id=".$_REQUEST['department_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:department.php");
	}
	
	?>
