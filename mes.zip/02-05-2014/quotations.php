<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:400px;width:750px;float:left;margin-top:100px;margin-left:30px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<div style="height:30px; width:750px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" color="white">All quotations information</font>
                    <a href="I_quotations.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from quotations";
	$result=mysqli_query($con,$qry);
echo '<div style="height:auto; width:750px;float:left;">';
	echo'<div style="height:20px; width:750px;color:white;">
		<div style="height:20px; width:90px; float:left; background:#00458f;">Quotation_id
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">customer_id
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">employee_id
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">Date
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">paymentermes
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">paid_date
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">Delete
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">UPDATE
		</div>
		<div style="height:20px; width:70px; float:left; background:#00458f;">VIEW
		</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:750px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:750px; background:silver;">';
			$cnt=0;
		}
		echo'<div style="height:20px; width:90px; float:left; ">'.$arr['Quotation_id'].'
				</div>
				<div style="height:20px; width:90px; float:left; "><a href="view_Quotations1.php?Quotation_id='.$arr['Quotation_id'].'">'.$arr['customer_id'].'</a>
				</div>
				<div style="height:20px; width:90px; float:left; "><a href="view_Quotations1.php?Quotation_id='.$arr['Quotation_id'].'">'.$arr['employee_pid'].'</a>
				</div>
				<div style="height:20px; width:90px; float:left; ">'.$arr['Date'].'
				</div>
				<div style="height:20px; width:90px; float:left; ">'.$arr['paymentermes'].'
				</div>
				<div style="height:20px; width:90px; float:left;">'.$arr['paid_date'].'
				</div>
				<div style="height:20px; width:70px; float:left; "><a href="delete_quotations.php?Quotation_id='.$arr['Quotation_id'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="update_Quotations1.php?Quotation_id='.$arr['Quotation_id'].'"><img src="images/update.png"/></a></div>
				<div style="height:20px; width:70px; float:left;"><a href="view_Quotations1.php?Quotation_id='.$arr['Quotation_id'].'">VIEW</a></div>
		</div>';
	}
echo"</div>";
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>