<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
                <div style="height:30px; width:600px; float:left; background-repeat:repeat-x;margin-top:100px;margin-left:50px; background-image:url(images/header1.png);">
	<font size="+2" color="white">All user_information</font>
		<a  href="user_info.php"style="float:left; margin-left:20px; color:white;">INSERT</a>
					</div>
				<div id="block32" style="font-family:Calibri;height:400px;width:600px;float:left;margin-left:50px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from user_info";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:600px;">';
	echo'<div style="height:20px; width:600px; color:white">
		<div style="height:20px; width:100px; float:left; background:#00458f;">emp_pid
		</div>
		<div style="height:20px; width:115px; float:left; background:#00458f;">user_name
		</div>
		<div style="height:20px; width:115px; float:left; background:#00458f;">password
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">DELETE
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">UPDATE
		</div>
		<div style="height:20px; width:90px; float:left; background:#00458f;">VIEW
		</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:600px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:600px; background:silver;">';
			$cnt=0;
		}

		echo'<div style="height:20px; width:100px; float:left;"><a href="view_user_info1.php?emp_pid='.$arr['emp_pid'].'">'.$arr['emp_pid'].'</a>
			</div>
			<div style="height:20px; width:115px; float:left;">'.$arr['user_name'].'
			</div>
			<div style="height:20px; width:115px; float:left;">'.$arr['password'].'
			</div>
			<div style="height:20px; width:90px; float:left;"><a href="delete_user_info.php?emp_pid='.$arr['emp_pid'].'"><img src="images/delete.png"/></a>
			</div>
			<div style="height:20px; width:90px; float:left;"><a href="update_user_info1.php?emp_pid='.$arr['emp_pid'].'"><img src="images/update.png"/></a></div>
			<div style="height:20px; width:90px; float:left;"><a href="view_user_info1.php?emp_pid='.$arr['emp_pid'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>