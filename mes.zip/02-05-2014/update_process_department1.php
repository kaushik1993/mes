<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from process_department";
    $resulta = mysqli_query($con,$qry);
	$resultb = mysqli_query($con,$qry);
   	$resultc = mysqli_query($con,$qry);
    
   
?>

				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from process_department where process_id='".$_REQUEST['process_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:380px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">Update For process_department</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">process_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="proce" value="<?php echo $row['plant_id'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">plant_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="plant_id" name="plant_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['plant_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">wherehouse_id :
		</div>
		<div style="height:25px; width:300px; float:left; margin-left:-10px;">
			<select id="wherehouse_id" name="wherehouse_id">
                 <?php
                while($row100=mysqli_fetch_array($resultc))
                {
                    echo '<option>';
                    $ei = $row100['wherehouse_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">start_date :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="star"  value="<?php echo $row['start_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" value="<?php echo $row['due_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">finished_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="finish" value="<?php echo $row['finished_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">status :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat" value="<?php echo $row['status'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">work_status :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="wor" value="<?php echo $row['work_status'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="desc" value="<?php echo $row['description'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update process_department set emp_pid='" . $_POST["emp_pid"] . "',plant_id='" . $_POST["plant_id"] . "',wherehouse_id='" . $_POST["wherehouse_id"] . "',start_date='" . $_POST["star"] . "',due_date='" . $_POST["date"] . "',finished_date='" . $_POST["finish"] ."',status='" . $_POST["stat"] . "',work_status='" . $_POST["wor"] . "',description='" . $_POST["desc"] ."' where process_id='".$_POST["proce"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:process_department.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>