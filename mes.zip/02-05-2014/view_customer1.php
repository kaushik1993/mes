<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1"><a href="Customer.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from customer where customer_id='".$_REQUEST['customer_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<body>
<form name="regi" method="post">
<div style="height:620px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;  background-image:url(images/header1.png);"><font size="+3" style="margin-left:80px;">View for Customer</font>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left; text-align:justify;">customer_id :->
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['customer_id'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left; text-align:justify;">Nameofcompany
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Nameofcompany'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;float:left;text-align:justify;">Nameofcust
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Nameofcust'];?>
		</div>
	</div>
	<div style="height:80px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;margin-top:20px;text-align:justify;">Address
		</div>
		<div style="height:88px; width:400px; float:left; margin-top:5px;">
			<?php echo $row['Address'];?>
			
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">City
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['City'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">State
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['State'];?>
		</div>
	</div>
	
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">country
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['country'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Website
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Website'];?>
		</div>
	</div>
		<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">jobpositions
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['jobpositions'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Mobile
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Mobile'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">E_mail
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['E_mail'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Salesperson
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Salesperson'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Supplier
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Supplier'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Reference
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Reference'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;text-align:justify;">Active
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Active'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">Language
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['Language'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">ReceiveMessagesBye_mail
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['ReceiveMessagesBye_mail'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">registereddate
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['registereddate'];?>
		</div>
	</div>
	<div style="height:20px; width:650px; float:left;margin-left:150px;">
		<div style="height:20px; width:150px; float:left;text-align:justify;">opt_out
		</div>
		<div style="height:20px; width:400px; float:left;">
			<?php echo $row['opt_out'];?>
		</div>
	</div>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>