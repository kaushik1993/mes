<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from rawmaterials";
    $resulta = mysqli_query($con,$qry);
   
    
   
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:350px;width:800px;float:left;margin-top:105px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
<form name="regi" method="post">
<div style="height:285px; width:800px;">
	<div style="height:50px; width:800px; float:left;;background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">purchases From</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">purch_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="prur" style=" margin-left:70px; background-color:#CCCCCC;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">raw_material_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="raw_material_id" name="raw_material_id" style=" margin-left:-30px;">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['raw_material_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">dealer :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="deal" style=" margin-left:-30px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">date_of_purchase :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date_of_purchase" style=" margin-left:-30px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify">paymentermes :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pay" style=" margin-left:-30px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="paym" style=" margin-left:70px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" style=" margin-left:70px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Sale_price :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sal" style=" margin-left:70px;" required/>
		</div>
	</div>
	
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Cost_Price :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cos" style=" margin-left:70px;" required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into purchases(raw_material_id,dealer,date_of_purchase,paymentermes,payment_type,due_date,Sale_price,Cost_Price)values(".$_POST['raw_material_id'].",'".$_POST['deal']."','".$_POST['date_of_purchase']."','".$_POST['pay']."','".$_POST['paym']."','".$_POST['date']."','".$_POST['sal']."','".$_POST['cos']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:purchases.php");
	
	mysqli_close($con);	
}
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>