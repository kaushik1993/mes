
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from finished_product_catagories where pro_cat_id=".$_REQUEST['pro_cat_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:finished_product_catagories.php");
	}
	
	?>
