<?php
include('head.php');
include('sidemenu.php');
?>

				<div id="block29" style="height:100px; width:1000px;float:left;">
					<div id="block29" style="height:60px; width:995px; float:left; margin-left:5px; margin-top:5px;">
						<div id="block29" style="height:50px; width:70px; background-color: #FFFFFF; float:left; margin-left:5px; margin-top:5px;"><img src="images/dashboard.png" height="50px" width="70px">
						</div>
							<div id="block29" style="height:50px; width:600px; text-align:left;float:left;font-family:Calibri; font-size:30px; margin-top:5px;text-shadow: 1px 5px 5px pink"> DashBoard
						</div>
					</div>
					<div id="block29" style="height:30px; width:980px; background-color:#e4e8ef; float:left; margin-left:10px;box-shadow:0px 0px 5px pink; z-index:20px; position:relative;">
						<div id="block29" class="library1">
						<img src="images/home.png" height="20px" width="30px">
						</div>
						<div id="block29" class="library">/</div>
						<div id="block29" class="library1">
						MES
						</div>
						<div id="block29" class="library">/</div>
						<div id="block29" class="library1">
						Dashboard
						</div>
					</div>
				</div>
				
				<div id="block30" class="overview1">
						<div id="block32" class="overview2">
							<div id="block21" class="overview3">
<?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	
    
	$sql = "select sum(paymentermes) as aa from salesorders where Date_of_sales like '%2011-02%'";
	$result = mysqli_query($con,$sql);
    $row = mysqli_fetch_array($result);
	$a = $row['aa'];
	$sql1 = "select sum(paymentermes) as bb from salesorders where Date_of_sales like '%2010-02%'";
	$result1 = mysqli_query($con,$sql1);
    $row1 = mysqli_fetch_array($result1);
	$b = $row1['bb'];
	$sql2 = "select sum(paymentermes) as cc from salesorders where Date_of_sales like '%2012-02%'";
	$result2 = mysqli_query($con,$sql2);
    $row2 = mysqli_fetch_array($result2);
	$c = $row2['cc'];
	$sql3 = "select sum(paymentermes) as dd from salesorders where Date_of_sales like '%2013-02%'";
	$result3 = mysqli_query($con,$sql3);
    $row3 = mysqli_fetch_array($result3);
	$d = $row3['dd'];
	$sql4 = "select sum(paymentermes) as ee from salesorders where Date_of_sales like '%2014-02%'";
	$result4 = mysqli_query($con,$sql4);
    $row4 = mysqli_fetch_array($result4);
	$e = $row4['ee'];
	include "libchart/classes/libchart.php";
	$chart = new PieChart();
	$chart->getPlot()->getPalette()->setPieColor(array(
		new Color(255, 0, 0),
		new Color(255, 255, 255)
	));
	$dataSet = new XYDataSet();
	$dataSet->addPoint(new Point("2011-02-01", $a));
	$dataSet->addPoint(new Point("2010-02-01", $b));
	$dataSet->addPoint(new Point("2012-02-01", $c));
	$dataSet->addPoint(new Point("2013-02-01", $d));
	$dataSet->addPoint(new Point("2014-02-01", $e));
	$chart->setDataSet($dataSet);
	$chart->setTitle("Deadly mushrooms");
	$chart->render("generated/pie_chart_color.png");
?><img alt="Pie chart color test"  src="generated/pie_chart_color.png" style=" height:256px; width:323px;"/>

							</div>
							<div id="block21" class="overview4">Profit graph
							</div>
						</div>
						<div id="block33" class="overview2">
							<div id="block21" class="overview3">
								<div id="block21" class="suboverview">
								<img src="images/SALE (2).png" height="120px" width="160px">
								</div>
								<div id="block21" style=" text-align:center; padding-top:30px;font-family:Calibri;
	box-shadow:0px 0px 3px #283c49;
	position:relative; 
	border-radius: 5px 5px 5px 5px;
	height:100px;
	width:154px;
	float:left;
	margin-left:5px;
	margin-top:35px;">
<font size="+5">
<?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from salesorders";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count;
?>
</font>
								</div>							
							</div>
							<div id="block21" class="overview4">Sales order
							</div>
						</div>
						<div id="block34" class="overview2">
							<div id="block38" class="overview5">Recent Purchase</div>
<font size="+5">							
<?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry11 = "select * from rawmaterials order by Products_Name DESC limit 0,3";
    $result11 = mysqli_query($con,$qry11);
	while($row11=mysqli_fetch_array($result11))
	{
	echo '<div id="block38" class="overview6">';
	$m=$row11['Products_Name'];
	echo $m;
	echo '</div>';
	}
?>
</font>
							
							
							
						</div>
				</div>
					
				<div id="block35" class="overview1">
						<div id="block21" class="overview7">
							<div id="block21" class="overview3">
								<div id="block21" class="suboverview">
								<img src="images/delivery.png" height="130px" width="150px">
								</div>
								<div id="block21" style=" text-align:center; padding-top:30px;font-family:Calibri;
	box-shadow:0px 0px 3px #283c49;
	position:relative; 
	border-radius: 5px 5px 5px 5px;
	height:100px;
	width:154px;
	float:left;
	margin-left:5px;
	margin-top:35px;" >
<font size="+5" >
<?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from supplier";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count;
	
?> </font>
								</div>
							</div>	
								<div id="block21" class="overview4">Supplier</div>
								</div>
							<div id="block37"class="overview7">
								<div id="block21" class="overview3">
	
<?php
 $con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	
    
	$sql5 = "select sum(amount) as ff from sales_particular where amount";
	$result5 = mysqli_query($con,$sql5);
    $row5= mysqli_fetch_array($result5);
	$f = $row5['ff'];
	echo $f;
	
	include "libchart/classes/libchart.php";

	$chart = new VerticalBarChart();

	$dataSet = new XYDataSet();
	$dataSet->addPoint(new Point("Jan 2010",$f));
	$chart->setDataSet($dataSet);
	$chart->setTitle("Monthly usage for www.example.com");
	$chart->render("generated/demo1.png");
?>
<img alt="Vertical bars  chart" src="generated/demo1.png" style=" height:256px; width:323px;"/>
							</div>
								<div id="block21" class="overview4">Sales graph</div>
							</div>
							<div id="block38" class="overview7">
								<div id="block38" class="overview8">
<font size="+5"><?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from customer";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count;
	
?> </font>customer</div>
								<div id="block38" class="overview8">
<font size="+5"><?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from quotations";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count;
	
?></font> quotations</div>
								<div id="block38" class="overview8">
<font size="+5"><?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from process_department";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count;
	
?></font> process</div>
								<div id="block38" class="overview8">
<font size="+5"><?php
$con=mysqli_connect("localhost","root","","mes");
  if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$qry = "select * from finished_product";
    $result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	echo $count; ?></font>
product</div>
</div>
</div>
</div>
</div>
<?php		
include('footer.php');
?>		


