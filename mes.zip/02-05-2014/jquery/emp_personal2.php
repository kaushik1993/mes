<html>
<head>
<title>Untitled Document</title>
</head>

<body>
<form name="regi" method="post">
<div style="height:555px; width:400px;margin-left:350px; margin-top:50px;">
	<div style="height:50px; width:400px; float:left;"><font size="+3" style="margin-left:80px;">emp_personal From</font>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">emp_pid
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="emp_id"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">first_name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="fname"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">last_name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="lname"/>
		</div>
	</div>
	<div style="height:80px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;">Address
		</div>
		<div style="height:88px; width:300px; float:left;">
			<textarea  name="add"style="height:70px; margin-top:2px;"></textarea>
			
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">contact
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="con"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">E_mail
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="mail"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">dateofbirth
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="date"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">city
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cit"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">state
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">country
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="countr"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">blodgroup
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="blodgr"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">gender
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="radio" id="radio" name="mal"/>male
			<input type="radio" id="radio" name="femal"/>female
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">adharcardno
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="adharcard"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">pancardno
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pancard"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">qulification
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="qul"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">Expiriance
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="expir"/>
		</div>
	</div>
	<div style="height:25px; width:400px; float:left;">
		<div style="height:25px; width:100px; float:left;">images
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="image" name="image" value="image" style="margin-top:2px; margin-left:2px;"/>
		</div>
	</div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:100px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
</body>
</html>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update emp_personal set first_name='" . $_POST["ftname"] . "',last_name='" . $_POST["lname"] . "',Address='" . $_POST["add"] . "',contact='" . $_POST["con"] . "',E_mail='" . $_POST["mail"] . "',dateofbirth='" . $_POST["date"] ."',city='" . $_POST["cit"] . "',state='" . $_POST["stat"] . "',country='" . $_POST["countr"] . "',blodgroup='" . $_POST["blodgr"]. "',gender='" . $_POST["mal"] ."',gender='" . $_POST["femal"] . "',adharcardno='" . $_POST["adharcard"] . "',pancardno='" . $_POST["pancard"] . "',qulification='" . $_POST["qul"] . "',Expiriance='" . $_POST["expir"] . "',images='". $_POST["image"] . "',opt_out='". $_POST["optut"] ."' where emp_pid='".$_POST["emp_id"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	echo "1 record added";
	
	mysqli_close($con);	
}
?>
