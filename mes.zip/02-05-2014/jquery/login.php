<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>welcome to login page</title>
<link href="style1.css" rel="stylesheet" type="text/css">
</head>
<body class="grad1">
<center>

<form name="login_frm" method="post">
	<font fa>
	<div style="height:500px; width:400px; margin-top:-2px;font-family:Calibri;text-shadow: 1px 2px 2px black; box-shadow:10px 10px 5000px white; z-index:auto;border-radius: 0px 100px 0px 100px;">
		<div  class="login1" class="grad1">
			<div style="height:150Px; width:400px;float:left; margin-top:7px;">
			<img src="images/lo.png" height="150px" width="150px">
			</div>
			<div style="height:50Px; width:400px;  float:left; margin-bottom:10px;">
			<h2>WELCOME</h2>
			</div>
			<div style="height:50Px; width:400px; float:left;">
			Manufacturing Execution System
			</div>
		</div>
		<div  class="login1">
			<div style="height:50Px; width:400px; float:left;">
			<input type="text" name="email" id="email" placeholder="username" vspace="20" size="45" />
			</div>
			<div style="height:50Px; width:400px;  float:left;">
			<input type="password" name="pass" id="pass" placeholder="password" size="45" />

			</div>
			<div style="height:50px; width:350px; float:left;" align="right">
			<a href="login.php" style="text-decoration:none; color:#716351; font-family:Calibri; text-shadow: 1px 2px 2px black;">Forget Password ?</a>
			</div>
			<div style="height:50px; width:300px; float:left; margin-left:50px; border-top-color:#808080; border-top-style:dashed; border-width:2px;">
			</div>
		</div>
	</div>
</center>
<div style="height:70Px; width:200px; float:right; bottom:0; right:0; margin-top:10px;">
		<div style="height:70Px; width:100px; float:left;">
		<input type="submit" value="Log In" class="button" id="btn_sbt" name="btn_sbt"/>
		</div>
		<div style="height:70Px; width:70px; float:left;">
		<img src="images/arrow.png" height="70px" width="70px;">
		</div>
	</div>
</form>
</body>
</html>
<?php
if(isset($_POST['btn_sbt']))
{
	session_start();
	$user_name = $_POST["email"];
	$password = $_POST["pass"];
	$con = mysqli_connect("localhost","root","","mes");
	if(!$con)
	{
		die('connection failed'.mysqli_error());
	}
	$qry = "SELECT * FROM user_info WHERE user_name='$user_name' AND password='$password'";
	$result = mysqli_query($con,$qry);
	$count = mysqli_num_rows($result);
	$row = mysqli_fetch_array($result);
	if($count>0)
	{
		echo "you are validate user.";
		$_SESSION['user_name']=$user_name;
		$_SESSION['password']=$password;
		$_SESSION['emp_pid']=$row['emp_pid'];
		header("location:main.php");
	}
	else
	{
		echo "sorry you credentials are not valid please try again.";
	}
}
?>
