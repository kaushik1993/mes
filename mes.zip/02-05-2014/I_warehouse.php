<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:350px;width:800px;float:left;margin-top:70px;margin-left:100px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
	<form name="regi" method="post">
<div style="height:300px; width:800px;">
	<div style="height:40px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">warehousemanagement Form</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align: justify;">wherehouse_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="where" style="margin-left:-75px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="descript"style="margin-left:25px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">Status :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align: justify;">Container_wise :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cont"style="margin-left:-75px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">Rack :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="rac"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">Row :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="ro"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">sales_in :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sa"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">sales_out
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sal"style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align: justify;">sales_return :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sale"style="margin-left:25px;" required/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into warehousemanagement(wherehouse_id,description,Status,Container_wise,Rack,Row,sales_in,sales_out,sales_return) values('".$_POST['whare']."','".$_POST['descript']."','".$_POST['stat']."','".$_POST['cont']."','".$_POST['rac']."','".$_POST['ro']."','".$_POST['sa']."','".$_POST['sal']."','".$_POST['sale']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:warehouse.php");
	
	mysqli_close($con);	
}
?>	
</div>
</div>
</div>
<?php		
include('footer.php');
?>