<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1"><a href="finished_product_types.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:250px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from finished_product_types where type_id='".$_REQUEST['type_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:250px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">View For finished_product_types</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">type_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['type_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">type_name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['type_name'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['creation_date'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['description'];?>
		</div>
	</div>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>