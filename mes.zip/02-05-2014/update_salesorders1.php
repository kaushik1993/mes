<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from salesorders";
    $resulta = mysqli_query($con,$qry);
	$resultb = mysqli_query($con,$qry);
    $qryc="Select * from emp_personal_information";
	$resultc = mysqli_query($con,$qryc);
?>
				

				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:50px;margin-left:100px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from salesorders where sales_id='".$_REQUEST['sales_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">Update For salesorders</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">sales_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="sal" value="<?php echo $row['sales_id'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">customer_id :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="customer_id" name="customer_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['customer_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Date_of_sales :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="da" value="<?php echo $row['Date_of_sales'];?>" required style="margin-left:30px;"/>
		</div>
	</div>

	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">Customer_Reference :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="custo" value="<?php echo $row['Customer_Reference'];?>" required style="margin-left:-50px;"/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">paymentermes :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="paym" value="<?php echo $row['paymentermes'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">invoice_lines :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="inv" value="<?php echo $row['invoice_lines'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">salesperson :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($resultc))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>	
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pay" value="<?php echo $row['payment_type'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="due" value="<?php echo $row['due_date'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:160px; float:left;text-align:justify;">ordertype_custsupplyer :		
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="ord" value="<?php echo $row['ordertype_custsupplyer'];?>" style="margin-left:-20px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">supplier_id :
		</div>
		<div style="height:25px; width:200px; float:left;">
			<select id="supplier_id" name="supplier_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['supplier_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:100px; margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update salesorders set customer_id='" . $_POST["customer_id"] . "',Date_of_sales='" . $_POST["da"] . "',Customer_Reference='" . $_POST["custo"] . "',paymentermes='" . $_POST["pay"] . "',invoice_lines='" . $_POST["inv"] ."',salesperson='" . $_POST["emp_pid"] . "',payment_type='" . $_POST["pay"] . "',due_date='" . $_POST["due"] ."',ordertype_custsupplyer='" . $_POST["ord"] . "',supplier_id='" . $_POST["supplier_id"] ."' where sales_id='".$_POST["sal"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:salesorders.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>