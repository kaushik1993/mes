<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:10px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
<form name="regi" method="post" enctype="multipart/form-data">
<div style="height:555px; width:800px;">
	<div style="height:50px; width:800px;float:left; background-repeat:repeat-x;  background-image:url(images/header1.png); color:#FFFFFF;">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">emp_personal_information Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid :
 		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="emp_pid" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">first_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="first_name" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">last_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="last_name" required=""/>
		</div>
	</div>
	<div style="height:60px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:88px; width:300px; float:left; margin-top:2px;">
			<textarea  name="Address" rows="3" cols="17" required=""></textarea>
			
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">contact :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="contact" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="E_mail" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">dateofbirth :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="dateofbirth" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">city :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="city" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="State" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">country :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="country" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">blodgroup :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="blodgroup" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">gender :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="radio" name="gender" value="female" required="">Female
  			 <input type="radio" name="gender" value="male" required="">Male
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">adharcardno :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="adharcardno" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pancardno :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pancardno" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">qualification :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="qualification" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Expiriance :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Expiriance" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">images :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="file" name="file" value="file" required=""/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
</div>


</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>
<?php

$con=mysqli_connect("localhost","root","","mes") or die("unable to connect");



function create_guid($namespace = 'www.ddl.com'){     
    static $guid = '';
    $uid = uniqid("", true);
    $data = $namespace;
    $data .= $_SERVER['REQUEST_TIME'];
    $data .= $_SERVER['HTTP_USER_AGENT'];
    $data .= $_SERVER['REMOTE_ADDR'];
    $data .= $_SERVER['REMOTE_PORT'];
    $hash = strtoupper(hash('ripemd128', $uid . $guid . md5($data)));
    $guid = substr($hash,  0,  8) . 
            substr($hash,  8,  4) .
            substr($hash, 12,  4) .
            substr($hash, 16,  4) .
            substr($hash, 20, 12);
    return $guid;
  }
  

if(isset($_POST['sbt']))
	{
	$id = $_FILES['file']['name'];
	$type=$_FILES['file']['type'];
	$data = $_FILES['file']['tmp_name'];
	$random = create_guid();
	
	$ext=end(explode(".",$id));
	$path= "images/".$random.".".$ext;
	
		$sql = "insert into emp_personal_information(first_name,last_name,Address,contact,E_mail,dateofbirth,city,State,country,blodgroup,gender,adharcardno,pancardno,qualification,Expiriance,image) values('".$_POST['first_name']."', '".$_POST['last_name']."','".$_POST['Address']."','".$_POST['contact']."','".$_POST['E_mail']."','".$_POST['dateofbirth']."','".$_POST['city']."','".$_POST['State']."','".$_POST['country']."','".$_POST['blodgroup']."','".$_POST['gender']."','".$_POST['adharcardno']."','".$_POST['pancardno']."','".$_POST['qualification']."','".$_POST['Expiriance']."','$path')";
        echo $sql;
		move_uploaded_file($_FILES['file']['tmp_name'],$path);		
	
		if(mysqli_query($con,$sql))
		$sqlimage="Select * from emp_personal_information";
		$resultimage=mysqli_query($con,$sqlimage);
		$rowimage=mysqli_fetch_array($resultimage);
		$image=$rowimage['image'];
		echo '<img src="$image"/>';
   
		header("location:emp_personal_information.php");
		
	}

?>