<?php
include('head.php');
include('sidemenu.php');
?>

				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:50px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:40px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">Supplier Form</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Supplier_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="supp"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Product_Name :
		</div>
		<div style="height:25px; width:300px; float:left; margin-left:-10px;">
			<input type="text" id="text" name="prod"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left;text-align:justify;">Name_company :
		</div>
		<div style="height:25px; width:300px; float:left; margin-left:-20;">
			<input type="text" id="text" name="name"/>
		</div>
	</div>
	<div style="height:80px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:88px; width:300px; float:left;margin-top:5px;">
				<textarea  name="add" rows="4" cols="17"></textarea>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">City :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cit"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Website :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Webs"/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">jobpositions :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="jobpos"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Mobile :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Mobil"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Fax :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="fa" />
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="mail"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">title :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="tit"/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into supplier values('".$_POST['supp']."','".$_POST['prod']."','".$_POST['name']."','".$_POST['add']."','".$_POST['cit']."','".$_POST['stat']."','".$_POST['Webs']."','".$_POST['jobpos']."','".$_POST['Mobil']."','".$_POST['fa']."','".$_POST['mail']."','".$_POST['tit']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:supplier.php");
	
	mysqli_close($con);	
}
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>