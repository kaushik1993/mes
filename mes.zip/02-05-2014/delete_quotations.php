<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from quotations where Quotation_id=".$_REQUEST['Quotation_id'];
	if(mysqli_query($con,$str))
	{
		header ("location:quotations.php");
	}
	
	?>
	