
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from purchases where purch_id=".$_REQUEST['purch_id']."";
	echo $qry;
	if(mysqli_query($con,$qry))
	{
		header ("location:purchases.php");
	}
	
	?>
