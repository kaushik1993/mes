<?php 
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
 	$sql = "select * from form ";
    $result = mysqli_query($con,$sql);
    $row = mysqli_fetch_array($result);
    $com = $row['companyname'];
    $add = $row['address'];
    $cont = $row['contactno'];
	$sql1 = "select * from process_department where process_id=".$_REQUEST['process_id'];
    $result1 = mysqli_query($con,$sql1);
    $row1 = mysqli_fetch_array($result1);
	$a = $row1['process_id'];
	$b = $row1['plant_id'];
	$c = $row1['wherehouse_id'];
	$d = $row1['emp_pid'];
	$e = $row1['description'];
	$f = $row1['start_date'];
	$g = $row1['due_date'];
	$h = $row1['finished_date'];
	$i = $row1['status'];
	$j = $row1['work_status'];
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Untitled Document</title>
</head>
<body>
<center>
	<div style="width:700px; height:555px; float:left; border:ridge;">
		<div style="width:700px; height:100px; float:left; border-bottom:ridge;">
			<div style="width:197px; height:100px; float:left; border-right:ridge;">
				<img src="images/social_stumbleupon_box_white.png" height="100px" width="197px">
			</div>
			<div style="width:500px; height:100px; float:left;">
            <font size="+2"> <?php
            echo $com."</br>".$add."</br>".$cont;
            ?></font>
			</div>
		</div>
		<div style="width:700px; height:30px; float:left; border-bottom:ridge;">
		INVOICE
		</div>
		<div style="width:700px; height:75px; float:left;border-bottom:ridge;">
		  	<div style="width:170px; height:75px; float:left; border-right:ridge; text-align:left;">
            process id :-<?php echo $a; ?>
            </div>
			<div style="width:170px; height:75px; float:left; border-right:ridge;text-align:left;">
            plant id :-<?php echo $b; ?>
			</div>
            <div style="width:170px; height:75px; float:left; border-right:ridge;text-align:left;">
            warehouse id :-<?php echo $c; ?>
            </div>
            <div style="width:170px; height:75px; float:left;text-align:left;">
            employee id :-<?php echo $d; ?>
            </div>
             <div style="width:700px; height:30px; float:left;border-bottom:ridge;">
                 <div style="width:100px; height:30px; float:left;border-right:ridge;">description
                 </div>
                 <div style="width:100px; height:30px; float:left;border-right:ridge;">start-date
                 </div>
                 <div style="width:100px; height:30px; float:left;border-right:ridge;">due-date
                 </div>
                 <div style="width:100px; height:30px; float:left;border-right:ridge;">finish-date
                 </div>
                 <div style="width:80px; height:30px; float:left;border-right:ridge;">status
                 </div>
                 <div style="width:205px; height:30px; float:left;">work-status
                 </div>
             </div>
        <div style="width:700px; height:200px; float:left;border-bottom:ridge;">
            <div style="width:100px; height:200px; float:left;border-right:ridge;">
			<?php echo $e; ?>
            </div>
            <div style="width:100px; height:200px; float:left;border-right:ridge;">
			<?php echo $f; ?>
            </div>
            <div style="width:100px; height:200px; float:left;border-right:ridge;">
			<?php echo $g; ?>
            </div>
            <div style="width:100px; height:200px; float:left;border-right:ridge;">
			<?php echo $h; ?>
            </div>
            <div style="width:80px; height:200px; float:left;border-right:ridge;">
			<?php echo $i; ?>
            </div>
            <div style="width:205px; height:200px; float:left;">
			<progress value="<?php echo $j;?>" max="100" ></progress><?php echo $j; ?>%
            </div>
        </div>
		<div style="width:700px; height:100px; float:left;">
				<div style="width:350px; height:110px; float:left;border-right:ridge;">
					<div style="width:350px; height:30px; float:left;">
					Authorized signature:-
					</div>
					<div style="width:350px; height:70px; float:left;">
					s.d.hirapara:-
					</div>
				</div>
				<div style="width:340px; height:100px; float:left;">
					<div style="width:350px; height:30px; float:left;">
					customer signature:-
					</div>
					<div style="width:350px; height:70px; float:left;">
					Kaushik Patel:-
					</div>
				</div>

		</div>
		</div>
	</div>
</center>
</body>
</html>
