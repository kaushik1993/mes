
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from salesreturn_orders where Sales_return_order_id=".$_REQUEST['Sales_return_order_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:salesreturn_orders.php");
	}
	
	?>
