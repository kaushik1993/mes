<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from rawmaterials";
    $resulta = mysqli_query($con,$qry);
	$resultb = mysqli_query($con,$qry);
?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:300px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from rawmaterials where raw_material_id='".$_REQUEST['raw_material_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
    $qry1="Select * from rawmaterialsproduct_types";
	$resultb = mysqli_query($con,$qry1);
    $resultc = mysqli_query($con,$qry1);
?>
<form name="regi" method="post">
<div style="height:300px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:50px;">Update For rawmaterials</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left; text-align:justify;">raw_material_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="raw_material_id" value="<?php echo $row['raw_material_id'];?>" required style="margin-left:60px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:210px; float:left; text-align:justify;">raw_materials_product_types	:
		</div>
		<div style="height:25px; width:100px; float:left;">
		<select id="raw_materials_product_types" name="raw_materials_product_types">
                 <?php
                while($row100=mysqli_fetch_array($resultc))
                {
                    echo '<option>';
                    $ei = $row100['raw_material_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align:justify;">Products_Name :
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="Products_Name" value="<?php echo $row['Products_Name'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Category_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<select id="Category_id" name="Category_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['Category_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">type_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="type_id" name="type_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['raw_material_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
            		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Description" value="<?php echo $row['Description'];?>" required style="margin-left:100px;"/>
		</div>
	</div>
	
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update rawmaterials set raw_materials_product_types='" . $_POST["raw_materials_product_types"] . "',Products_Name='" . $_POST["Products_Name"] . "',Category_id='" . $_POST["Category_id"] . "',type_id='" . $_POST["type_id"] . "',Description='" . $_POST["Description"] . "' where raw_material_id='".$_POST["raw_material_id"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:rawmaterials.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
		
<?php		
include('footer.php');
?>