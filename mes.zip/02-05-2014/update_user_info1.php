<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from user_info";
    $resulta = mysqli_query($con,$qry);

?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:280px;width:700px;float:left;margin-top:100px;margin-left:120px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from user_info where emp_pid='".$_REQUEST['emp_pid']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:160px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:50px;">Update For User_info</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid :	
		</div>
		<div style="height:25px; width:300px;float:left;">
			<select>
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>

		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">user_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="user_name" value="<?php echo $row['user_name'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">password :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="password" value="<?php echo $row['password'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update user_info set user_name='" . $_POST["user_name"] . "',password='" . $_POST["password"] ."'where emp_pid='".$_POST["emp_pid"]."'";
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:user_info.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>