<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from customer where customer_id=".$_REQUEST['customer_id'];
	if(mysqli_query($con,$str))
	{
		header ("location:customer.php");
	}
	
	?>
	
    
  