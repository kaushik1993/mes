
		<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<form name="regi" method="post">
<div style="height:505px; width:800px;">
	<div style="height:30px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">Customer Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">customer_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="custom" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Nameofcompany :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Nameofcom" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Nameofcust :
		</div>
		<div style="height:25px; width:300px; float:left; ">
			<input type="text" id="text" name="Nameofcu" required/>
		</div>
	</div>
	<div style="height:60px; width:800px; float:left;  margin-left:150px;">
		<div style="height:60px; width:150px; float:left;margin-top:25px;">Address :
		</div>
		<div style="height:60px; width:300px; float:left;margin-top:2px;">
			<textarea  name="add" rows="3" cols="17"></textarea>
			
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">City :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cit" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat" required/>
		</div>
	</div>
	
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">country :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="countr" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Website :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Webs" required/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">jobpositions :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="jobpos" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Mobile :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Mobil" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="mail" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Salesperson :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Salesp" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Supplier :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Suppl" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">reference :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="refer" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Active :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Activ" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">Language :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Lang" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">ReceiveMessagesBye_mail : 
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="receive" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">registereddate :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="date" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;  margin-left:150px;">
		<div style="height:25px; width:150px; float:left;">opt_out :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="optut"required/>
		</div>
	</div>
	<input type="submit" name="sbt" value="Submit" style=" margin-left:150px;margin-top:5px;" />
	<input type="reset" name="btnclear" value="Reset" />
</div>
</form>
</div>
</div>
</div>
