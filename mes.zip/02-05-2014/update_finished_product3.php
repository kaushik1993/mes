<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from finished_product";
    $resulta = mysqli_query($con,$qry);
	$resultb = mysqli_query($con,$qry);
?>
<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:300px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from finished_product where pro_id='".$_REQUEST['pro_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:300px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">Update For finished_product</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pro_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pro_id" value="<?php echo $row['pro_id'];?>" required style=" margin-left:70px;"/>
		</div>
			</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="na" value="<?php echo $row['name'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Category :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Category" name="Category">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['Category'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Product_type :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Product_type" name="Product_type">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['Product_type'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="descript" value="<?php echo $row['description'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update finished_product set name='" . $_POST["na"] . "',Category='" . $_POST["Category"] . "',Product_type='" . $_POST["Product_type"] . "',description='" . $_POST["descript"] 
	."' where pro_id='".$_POST["pro_id"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:finished_product.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>