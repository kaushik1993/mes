
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from plant_department where plant_id=".$_REQUEST['plant_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:plant_department.php");
	}
	
	?>
