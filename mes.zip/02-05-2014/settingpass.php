<?php
include('head.php');
include('sidemenu.php');
?>

<?php									
	
	if($_SESSION['user_name']=="" or $_SESSION['password']=="")
	{
		
	}
	
	
	if(isset($_POST['sbt']))
	{
	   if($_POST['old']==$_SESSION['password'] && $_POST['new'] == $_POST['renew'])
       {   	
		$conn=mysqli_connect("localhost","root","","mes") or die("unable to connect");
		
		$str="update user_info set password='".$_POST['renew']."' where emp_pid='".$_SESSION['emp_pid']."'";
	   	
           
           if(mysqli_query($conn,$str))
            echo "password has been update";   
		else	
			echo "Error : ".mysqli_error();
	
    	mysqli_close($conn);
    }
    else
    {
        echo "<span style='color:red;'>Please enter your password properly</span>";
    }
		

	}
	
?>

	<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:800px;float:left;margin-top:70px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
	<form name="regi" method="post">
<div style="height:160px; width:800px;">
	<div style="height:50px; width:800px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" style="text-shadow: 1px 2px 2px white;">user_info Form</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;">old_password	
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="old" name="old" style="margin-left:25px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;">new_password
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="new" name="new" style="margin-left:25px;" required/>
		</div>
	</div>
	
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;">confirm_password	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="renew" name="renew" style="margin-left:25px;" required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	

</div>
</form>

</div>
</div>
</div>
<?php		
include('footer.php');
?>