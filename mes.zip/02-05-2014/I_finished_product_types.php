<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:800px;float:left;margin-top:105px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
<form name="regi" method="post">
<div style="height:190px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x; background-image:url(images/header1.png);">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">finished_product_types Form</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">type_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="type" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">type_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="name" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="creation" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="desc" style=" margin-left:70px;"required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into finished_product_types(type_id,type_name,creation_date,Description) values('".$_POST['type']."','".$_POST['name']."','".$_POST['creation']."','".$_POST['desc']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:finished_product_types.php");
	
	mysqli_close($con);	
}
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>