<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from finished_product_catagories where pro_cat_id='".$_REQUEST['pro_cat_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:250px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">Update For finishes_catagories_catagories</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left; text-align:justify;">pro_cat_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pro"  value="<?php echo $row['pro_cat_id'];?>" required style=" margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Category_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="categ"  value="<?php echo $row['Category_name'];?>" required style=" margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="creation"  value="<?php echo $row['creation_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="desc"  value="<?php echo $row['Description'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update finished_product_catagories set Category_name='" . $_POST["categ"] . "',creation_date='" . $_POST["creation"] . "',Description='" . $_POST["desc"] 
	."' where pro_cat_id='".$_POST["pro"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:finished_product_catagories.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>