<?php
	 session_start();
	if(!isset($_SESSION['user_name']) or !isset($_SESSION['password']))
	{
	  header("location:index.php");
	}
?>
<?php
	 
	$con = mysqli_connect("localhost","root","","mes");
	$qry="SELECT * FROM emp_personal_information WHERE emp_pid=".$_SESSION['emp_pid']."";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<html>
<head>
<title>manufacturing execution system</title>
<link href="a.js" rel="stylesheet" type="text/css">
<script  src="jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
	$("#customer").click(function(){
	
		$("#hide").toggle("slow");
		$("#hide1").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#quatation").click(function(){
		$("#hide1").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#purchase").click(function(){
		$("#hide2").toggle("slow");
		$("#hide").hide("slow");
		$("#hide1").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#rawmaterial").click(function(){
		$("#hide3").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide1").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#warehouse").click(function(){
	$("#hide4").toggle("slow");
	$("#hide").hide("slow");
	$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide1").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#plant").click(function(){
		$("#hide5").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide1").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#department").click(function(){
		$("#hide6").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide1").hide("slow");
		$("#hide5").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#process").click(function(){
		$("#hide7").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide1").hide("slow");
		$("#hide6").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#finished_product").click(function(){
		$("#hide8").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide1").hide("slow");
		$("#hide7").hide("slow");
		$("#hide6").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#employee").click(function(){
		$("#hide9").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide1").hide("slow");
		$("#hide8").hide("slow");
		$("#hide7").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#supplier").click(function(){
		$("#hide10").toggle("slow");
		$("#hide").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide1").hide("slow");
		$("#hide9").hide("slow");
		$("#hide8").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#salesorder").click(function(){
		$("#hide11").toggle("slow");
		$("#hide").hide("slow");
		$("#hide1").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide12").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#salesorderreturn").click(function(){
		$("#hide12").toggle("slow");
		$("#hide").hide("slow");
		$("#hide1").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide13").hide("slow");
	});
});
</script>
<script>
$(document).ready(function(){
	$("#contect").click(function(){
		$("#hide13").toggle("slow");
		$("#hide").hide("slow");
		$("#hide1").hide("slow");
		$("#hide2").hide("slow");
		$("#hide3").hide("slow");
		$("#hide4").hide("slow");
		$("#hide5").hide("slow");
		$("#hide6").hide("slow");
		$("#hide7").hide("slow");
		$("#hide8").hide("slow");
		$("#hide9").hide("slow");
		$("#hide10").hide("slow");
		$("#hide11").hide("slow");
		$("#hide12").hide("slow");
		
	});
});
</script>
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>

<center>
<div id="1" style="height:940px; width:1200px;">
	<div id="header" style="height:45px; width:1200px; background-image:url(images/header.png); background-size:1200px 50px;  margin-top:-7px; box-shadow: 0px 5px 5px black; z-index:3; position:relative; margin-bottom:10px;">
	
			<div id="logo" style="height:42px;width:80px;float:left;margin-left:2px;margin-top:2px;box-shadow:0px 0px 3px white;position:relative;border-radius:5px 5px 5px; background:#FFFFFF">
			<img src="images/logo.png" height="40px" width="70px;">

			</div>
			<div id="name" style="height:45px;width:700px;float:left;">
			</div>
			<div id="userprofile" style="height:43px; width:418px;float:left;margin-top:8px;border-radius:10px 10px 10px;">
			
				<div id="userprofile" style="height:43px; width:160px;float:left;border-radius:10px 10px 10px;">
					<font size="+2" color="#FFFFFF"><?php echo $row['first_name']." ".$row['last_name']; ?>	</font>
				</div>
				<div id="userprofile" style="height:45px; width:60px;float:left; margin-top:-7px;">
				
					<?php
					$con=mysqli_connect("localhost","root","","mes") or die("unable to connect");
					$sqlimage="Select * from emp_personal_information where emp_pid='".$_SESSION['emp_pid']."'";
		$resultimage=mysqli_query($con,$sqlimage);
		$rowimage=mysqli_fetch_array($resultimage);
		$image=$rowimage['image'];
		?> <img src="<?php echo $image; ?>" style="width:60px; height:45px;"/> <?php
		?>	</font>
				</div>
                 <div class="sortcut0">
                     <a href="log_out.php" class="hi-icon-effect"><div class="hi-icon"><font color="white" size="+1"></font></div></a>
                 </div>
            </div>
			
	</div>