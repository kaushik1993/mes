
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from emp_official_information where emp_pid=".$_REQUEST['emp_pid']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:emp_official_information.php");
	}
	
	?>
