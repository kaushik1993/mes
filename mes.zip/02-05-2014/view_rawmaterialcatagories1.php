<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1"><a href="rawmaterialcatagories.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:300px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from rawmaterialcatagories where Category_id='".$_REQUEST['Category_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:300px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">View For rawmaterialcatagories</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Category_id
		</div>
		<div style="height:25px; width:300px;float:left;">
			<?php echo $row['Category_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">raw_materials_product_type_id	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['raw_materials_product_type_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align:justify;">Category_name
		</div>
		<div style="height:25px; width:250px; float:left;">
			<?php echo $row['Category_name'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">creation_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['creation_date'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Description
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Description'];?>
		</div>
	</div>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>