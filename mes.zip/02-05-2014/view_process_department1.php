<?php
include('head.php');
include('sidemenu.php');
?>

				
				<div id="block30" class="overview1"><a href="process_department.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from process_department where process_id='".$_REQUEST['process_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:380px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">view For process_department</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">process_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<a href="receipet.php?process_id=<?php echo $row['process_id'];?>"><?php echo $row['process_id'];?></a>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">employee_pid
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['emp_pid'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">plant_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['plant_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">wherehouse_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['wherehouse_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">start_date	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['start_date'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['due_date'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">finished_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['finished_date'];?>
		</div>
	</div>
	
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">status
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['status'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">work_status
		</div>
		<div style="height:25px; width:300px; float:left;"> 
        <progress value="<?php echo $row['work_status']; ?>" max="100" ></progress><?php echo $row['work_status']; ?>
		%</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['description'];?>
		</div>
	</div>

</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>