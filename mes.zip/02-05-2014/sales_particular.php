<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	
   
    
   
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:500px;width:900px;float:left;margin-top:105px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;  overflow:auto;">
<form name="regi" method="post">
<div style="height:500px; width:900px;">
	<div style="height:50px; width:900px; float:left;background-repeat:repeat-x;  background-image:url(images/header1.png); color:#FFFFFF;">
	<font size="+2"style="text-shadow: 1px 2px 1px white;">sales_particular form</font>
	</div>
	<div style="height:400px; width:900px; float:left;">
<?php
$n=$_REQUEST['no_of_product'];
$sales_id=$_REQUEST['sales_id'];
$i=1;
for($i;$i<=$n;$i++)
{
			$qry="Select * from finished_product";
    		$resulta = mysqli_query($con,$qry);

		echo'<div style="height:50px; width:240px; float:left;">
			<div style="height:50px; width:80px; float:left;">pro_id</div>
			<div style="height:50px; width:160px; float:left;">
			<select id="pro_id" name="pro_id">';
      
               		 while($row100=mysqli_fetch_array($resulta))
               		 {
                    echo '<option>';
                    $ei = $row100['pro_id'];
                    echo $ei;
                    echo '</option>';
               		 }
           
                
          echo '</select>
			</div>
		</div>';
		echo'<div style="height:50px; width:230px; float:left;">
			<div style="height:50px; width:70px; float:left;">Quantity</div>
			<div style="height:50px; width:160px; float:left;"><input type="text" id="quantity'.$i.'" name="quantity'.$i.'"></div>
		</div>';
		echo'<div style="height:50px; width:210px; float:left;">
			<div style="height:50px; width:50px; float:left;">Rate</div>
			<div style="height:50px; width:160px; float:left;"><input type="text" id="rate'.$i.'" name="rate'.$i.'"></div>

		</div>';
		echo'<div style="height:50px; width:220px; float:left;">
			<div style="height:50px; width:60px; float:left;">Amount</div>
			<div style="height:50px; width:160px; float:left;"><input type="text" id="amount'.$i.'" name="amount'.$i.'"></div>
		</div>';
}
?>	
		<div style="height:50px; width:300px; float:left;">
		<input type="submit" id="sub" name="sub" value="Submit">
		</div>
		<div style="height:50px; width:300px; float:left;">
		<input type="reset" id="cnt" name="cnt" value="Cancel">
		</div>

</div>
</div>
</form>
<?php
if(isset($_POST['sub']))
{
if($n==1)
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id1']."','".$_POST['quantity1']."','".$_POST['rate1']."','".$_POST['amount1']."')";
mysqli_query($con,$sql);
}
elseif($n==2)
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id1']."','".$_POST['quantity1']."','".$_POST['rate1']."','".$_POST['amount1']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id2']."','".$_POST['quantity2']."','".$_POST['rate2']."','".$_POST['amount2']."')";
mysqli_query($con,$sql);
}
elseif($n==3)
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id1']."','".$_POST['quantity1']."','".$_POST['rate1']."','".$_POST['amount1']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id2']."','".$_POST['quantity2']."','".$_POST['rate2']."','".$_POST['amount2']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id3']."','".$_POST['quantity3']."','".$_POST['rate3']."','".$_POST['amount3']."')";
mysqli_query($con,$sql);
}
elseif($n==4)
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id1']."','".$_POST['quantity1']."','".$_POST['rate1']."','".$_POST['amount1']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id2']."','".$_POST['quantity2']."','".$_POST['rate2']."','".$_POST['amount2']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id3']."','".$_POST['quantity3']."','".$_POST['rate3']."','".$_POST['amount3']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id4']."','".$_POST['quantity4']."','".$_POST['rate4']."','".$_POST['amount4']."')";
mysqli_query($con,$sql);
}
elseif($n==5)
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id1']."','".$_POST['quantity1']."','".$_POST['rate1']."','".$_POST['amount1']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id2']."','".$_POST['quantity2']."','".$_POST['rate2']."','".$_POST['amount2']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id3']."','".$_POST['quantity3']."','".$_POST['rate3']."','".$_POST['amount3']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id4']."','".$_POST['quantity4']."','".$_POST['rate4']."','".$_POST['amount4']."')";
mysqli_query($con,$sql);
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into sales_particular(sales_id,pro_id,quantity,Rate,amount) values($sales_id,'".$_POST['pro_id5']."','".$_POST['quantity5']."','".$_POST['rate5']."','".$_POST['amount5']."')";
mysqli_query($con,$sql);
}
	 header("location:invoice.php?sales_id=".$sales_id);
	mysqli_close($con);
}
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>