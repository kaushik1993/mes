<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
                <div style="height:30px; width:915px; float:left; background-repeat:repeat-x;margin-top:100px;margin-left:80px; background-image:url(images/header1.png);">
	                       <font size="+2" color="white">All salesreturn_orders information</font>
                    <a href="I_salesreturn.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>

					<div id="block32" style="font-family:Calibri;height:400px;width:915px;float:left;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:1px 1px 5px 5px; overflow: auto;">
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from salesreturn_orders";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:915px;">';
	echo'<div style="height:20px; width:915px; color:white;">
			<div style="height:20px; width:145px; float:left; background:#00458f;">Sales_return_order_id
			</div>
			<div style="height:20px; width:100px; float:left; background:#00458f;">Customer
			</div>
			<div style="height:20px; width:160px; float:left; background:#00458f;">sales_Date_return_date	
			</div>
			<div style="height:20px; width:150px; float:left; background:#00458f;">Customer_Reference
			</div>
			<div style="height:20px; width:100px; float:left; background:#00458f;">paymentermes
			</div>
			<div style="height:20px; width:80px; float:left; background:#00458f;">due_date
			</div>
			<div style="height:20px; width:60px; float:left; background:#00458f;">DELETE
			</div>
			<div style="height:20px; width:60px; float:left; background:#00458f;">UPDATE
			</div>
			<div style="height:20px; width:60px; float:left; background:#00458f;">VIEW
			</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:915px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:915px; background:silver;">';
			$cnt=0;
		}
		
			echo'<div style="height:20px; width:145px; float:left;">'.$arr['Sales_return_order_id'].'
				</div>
				<div style="height:20px; width:100px; float:left;">'.$arr['Customer'].'
				</div>
				<div style="height:20px; width:160px; float:left;">'.$arr['sales_Date_return_date'].'
				</div>
				<div style="height:20px; width:150px; float:left;">'.$arr['Customer_Reference'].'
				</div>
				<div style="height:20px; width:100px; float:left;">'.$arr['paymentermes'].'
				</div>
				<div style="height:20px; width:80px; float:left;">'.$arr['due_date'].'
				</div>
				<div style="height:20px; width:60px; float:left;"><a href="delete_salesreturn_orders.php?Sales_return_order_id='.$arr['Sales_return_order_id'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:60px; float:left;"><a href="update_salesreturn2.php?Sales_return_order_id='.$arr['Sales_return_order_id'].'"><img src="images/update.png"/></a></div>
				<div style="height:20px; width:60px; float:left;"><a href="view_salesreturn2.php?Sales_return_order_id='.$arr['Sales_return_order_id'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>
</div>
</div>
</div>
<?php		
include('footer.php');
?>