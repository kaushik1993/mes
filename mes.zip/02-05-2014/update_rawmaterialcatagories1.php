<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:300px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from rawmaterialcatagories where Category_id='".$_REQUEST['Category_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
    $qry="Select * from finished_product_types";
    $result = mysqli_query($con,$qry);
?>
<form name="regi" method="post">
<div style="height:300px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">Update For rawmaterialcatagories</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Category_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="cat" value="<?php echo $row['Category_id'];?>" required  style="margin-left:100px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:220px; float:left; text-align:justify;">raw_materials_product_type_id :	
		</div>
		<div style="height:25px; width:100px; float:left;">
		<select id="raw_materials_product_type_id" name="raw_materials_product_type_id">
                 <?php
                while($row100=mysqli_fetch_array($result))
                {
                    echo '<option>';
                    $ei = $row100['type_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left; text-align:justify;">Category_name :
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="cate" value="<?php echo $row['Category_name'];?>" required  style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="crea" value="<?php echo $row['creation_date'];?>" required  style="margin-left:100px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left; text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="des" value="<?php echo $row['Description'];?>" required  style="margin-left:100px;"/>
		</div>
	</div>
	
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update rawmaterialcatagories set raw_materials_product_type_id='" . $_POST["raw_materials_product_type_id"] . "',Category_name='" . $_POST["cate"] . "',creation_date='" . $_POST["crea"] . "',Description='" . $_POST["des"] 
	."' where Category_id='".$_POST["cat"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:rawmaterialcatagories.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>