-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2014 at 12:28 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mes`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(20) NOT NULL AUTO_INCREMENT,
  `Nameofcompany` varchar(30) NOT NULL,
  `Nameofcust` varchar(30) NOT NULL,
  `Address` varchar(2000) NOT NULL,
  `City` varchar(60) NOT NULL,
  `State` varchar(60) NOT NULL,
  `country` varchar(60) NOT NULL,
  `Website` varchar(40) NOT NULL,
  `jobpositions` varchar(20) NOT NULL,
  `Mobile` int(18) NOT NULL,
  `E_mail` varchar(60) NOT NULL,
  `Salesperson` varchar(60) NOT NULL,
  `Supplier` varchar(30) NOT NULL,
  `Reference` varchar(20) NOT NULL,
  `Active` varchar(40) NOT NULL,
  `Language` varchar(20) NOT NULL,
  `ReceiveMessagesBye_mail` varchar(60) NOT NULL,
  `registereddate` date NOT NULL,
  `opt_out` int(18) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `Nameofcompany`, `Nameofcust`, `Address`, `City`, `State`, `country`, `Website`, `jobpositions`, `Mobile`, `E_mail`, `Salesperson`, `Supplier`, `Reference`, `Active`, `Language`, `ReceiveMessagesBye_mail`, `registereddate`, `opt_out`) VALUES
(4, 'mes', 'kaushik', 'surat', 'surat', 'gujrat', 'india', 'www.mes.com', 'bca', 2147483647, 'mes155@gmail.com', '12', '12', 'manager', 'bca', 'english', 'mes122@gmail.com', '2012-02-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `department_id` int(20) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(20) NOT NULL,
  `department_add` varchar(50) NOT NULL,
  `department_contect` int(18) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `department`
--


-- --------------------------------------------------------

--
-- Table structure for table `emp_official_information`
--

CREATE TABLE IF NOT EXISTS `emp_official_information` (
  `emp_pid` int(20) NOT NULL,
  `Designation` varchar(200) NOT NULL,
  `Department_id` int(20) NOT NULL,
  `basesalary` int(20) NOT NULL,
  `ta` int(20) NOT NULL,
  `da` int(20) NOT NULL,
  `hra` int(20) NOT NULL,
  `pf` int(20) NOT NULL,
  `grosssalary` int(20) NOT NULL,
  `JoiningDate` date NOT NULL,
  `workinghours` double NOT NULL,
  KEY ` Employeeper_id` (`emp_pid`),
  KEY ` Department_id` (`Department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_official_information`
--


-- --------------------------------------------------------

--
-- Table structure for table `emp_personal_information`
--

CREATE TABLE IF NOT EXISTS `emp_personal_information` (
  `emp_pid` int(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `contact` int(18) NOT NULL,
  `E_mail` varchar(60) NOT NULL,
  `dateofbirth` date NOT NULL,
  `city` varchar(50) NOT NULL,
  `State` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `blodgroup` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `adharcardno` int(20) NOT NULL,
  `pancardno` varchar(20) NOT NULL,
  `qualification` varchar(20) NOT NULL,
  `Expiriance` int(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`emp_pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `emp_personal_information`
--

INSERT INTO `emp_personal_information` (`emp_pid`, `first_name`, `last_name`, `Address`, `contact`, `E_mail`, `dateofbirth`, `city`, `State`, `country`, `blodgroup`, `gender`, `adharcardno`, `pancardno`, `qualification`, `Expiriance`, `image`) VALUES
(8, 'kaushik', 'nakrani', '125 patel park', 123456789, 'mes155@gmail.com', '2011-10-29', 'surat', 'gujarat', 'india', 'o+', 'male', 0, '4568791212', 'bca', 2, 'images/ED9CB983EB75C434E1E8B4D57BDECB05.png'),
(9, 'sudhir', 'hirapara', '43-subhlaxmi soc', 2147483647, 'bca@gmail.com', '2013-10-30', 'surat', 'gujarat', 'india', 'o+', 'male', 2147483647, '7777777', 'bca', 2, 'images/237EE1673AC6A51100899C6ACFE6CE42.png');

-- --------------------------------------------------------

--
-- Table structure for table `finished_product`
--

CREATE TABLE IF NOT EXISTS `finished_product` (
  `pro_id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `Category` int(20) NOT NULL,
  `Product_type` int(20) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`pro_id`),
  KEY `Category` (`Category`),
  KEY `Product_type` (`Product_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finished_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `finished_product_catagories`
--

CREATE TABLE IF NOT EXISTS `finished_product_catagories` (
  `pro_cat_id` int(20) NOT NULL AUTO_INCREMENT,
  `Category_name` varchar(20) NOT NULL,
  `creation_date` varchar(60) NOT NULL,
  `Description` varchar(20) NOT NULL,
  PRIMARY KEY (`pro_cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finished_product_catagories`
--


-- --------------------------------------------------------

--
-- Table structure for table `finished_product_types`
--

CREATE TABLE IF NOT EXISTS `finished_product_types` (
  `type_id` int(20) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL,
  `creation_date` varchar(20) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finished_product_types`
--


-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE IF NOT EXISTS `form` (
  `companyname` varchar(40) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contactno` int(18) NOT NULL,
  `tnl_stno` int(10) NOT NULL,
  `tnl_ctno` int(10) NOT NULL,
  `terms_condition1` varchar(100) NOT NULL,
  `terms_condition2` varchar(100) NOT NULL,
  `terms_condition3` varchar(100) NOT NULL,
  `terms_condition4` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--


-- --------------------------------------------------------

--
-- Table structure for table `plant_department`
--

CREATE TABLE IF NOT EXISTS `plant_department` (
  `plant_id` int(20) NOT NULL AUTO_INCREMENT,
  `plant_name` varchar(50) NOT NULL,
  `Address` varchar(2000) NOT NULL,
  `contact` int(18) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `creation_date` date NOT NULL,
  `machinary_information` varchar(2000) NOT NULL,
  PRIMARY KEY (`plant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `plant_department`
--


-- --------------------------------------------------------

--
-- Table structure for table `process_department`
--

CREATE TABLE IF NOT EXISTS `process_department` (
  `process_id` int(20) NOT NULL AUTO_INCREMENT,
  `emp_pid` int(20) NOT NULL,
  `plant_id` int(20) NOT NULL,
  `wherehouse_id` int(20) NOT NULL,
  `start_date` int(20) NOT NULL,
  `due_date` date NOT NULL,
  `finished_date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `work_status` double NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`process_id`),
  KEY `employee id` (`emp_pid`),
  KEY `plant id` (`plant_id`),
  KEY `wherehouse id` (`wherehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `process_department`
--


-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `purch_id` int(20) NOT NULL AUTO_INCREMENT,
  `raw_material_id` int(20) NOT NULL,
  `dealer` varchar(20) NOT NULL,
  `date_of_purchase` date NOT NULL,
  `paymentermes` int(20) NOT NULL,
  `payment_type` varchar(80) NOT NULL,
  `due_date` date NOT NULL,
  `Sale_price` int(20) NOT NULL,
  `Cost_Price` int(20) NOT NULL,
  PRIMARY KEY (`purch_id`),
  KEY `raw_material_id` (`raw_material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `purchases`
--


-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE IF NOT EXISTS `quotations` (
  `Quotation_id` int(20) NOT NULL AUTO_INCREMENT,
  `customer_id` int(20) NOT NULL,
  `employee_pid` int(20) NOT NULL,
  `Customer` varchar(2000) NOT NULL,
  `Date` date NOT NULL,
  `paymentermes` varchar(20) NOT NULL,
  `invoice_lines` varchar(40) NOT NULL,
  `salesperson` int(20) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `paid_date` date NOT NULL,
  `ordertype_custsupplyer` varchar(50) NOT NULL,
  PRIMARY KEY (`Quotation_id`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_pid`),
  KEY `salesperson` (`salesperson`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`Quotation_id`, `customer_id`, `employee_pid`, `Customer`, `Date`, `paymentermes`, `invoice_lines`, `salesperson`, `payment_type`, `paid_date`, `ordertype_custsupplyer`) VALUES
(1, 4, 8, 'kashik', '2012-05-10', '12345678', '12', 8, 'cash', '2012-12-12', 'sales'),
(2, 4, 8, 'kashik', '2012-05-10', '12345678', '12', 8, 'cash', '2012-12-12', 'sales');

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterialcatagories`
--

CREATE TABLE IF NOT EXISTS `rawmaterialcatagories` (
  `Category_id` int(20) NOT NULL AUTO_INCREMENT,
  `raw_materials_product_type_id` int(20) NOT NULL,
  `Category_name` varchar(60) NOT NULL,
  `creation_date` date NOT NULL,
  `Description` varchar(2000) NOT NULL,
  PRIMARY KEY (`Category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `rawmaterialcatagories`
--

INSERT INTO `rawmaterialcatagories` (`Category_id`, `raw_materials_product_type_id`, `Category_name`, `creation_date`, `Description`) VALUES
(1, 2, 'kaushik', '2012-01-12', 'sales');

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterials`
--

CREATE TABLE IF NOT EXISTS `rawmaterials` (
  `raw_material_id` int(20) NOT NULL AUTO_INCREMENT,
  `raw_materials_product_types` int(20) NOT NULL,
  `Products_Name` varchar(80) NOT NULL,
  `Category_id` int(20) NOT NULL,
  `type_id` int(20) NOT NULL,
  `Description` varchar(2000) NOT NULL,
  PRIMARY KEY (`raw_material_id`),
  KEY `Category_id` (`Category_id`),
  KEY ` type_id` (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `rawmaterials`
--


-- --------------------------------------------------------

--
-- Table structure for table `rawmaterialsproduct_types`
--

CREATE TABLE IF NOT EXISTS `rawmaterialsproduct_types` (
  `raw_material_id` int(20) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL,
  `creation_date` date NOT NULL,
  `Description` varchar(2000) NOT NULL,
  PRIMARY KEY (`raw_material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `rawmaterialsproduct_types`
--

INSERT INTO `rawmaterialsproduct_types` (`raw_material_id`, `type_name`, `creation_date`, `Description`) VALUES
(1, 'kaushik', '2012-12-12', 'sales');

-- --------------------------------------------------------

--
-- Table structure for table `salesorders`
--

CREATE TABLE IF NOT EXISTS `salesorders` (
  `sales_id` int(20) NOT NULL AUTO_INCREMENT,
  `customer_id` int(20) NOT NULL,
  `Date_of_sales` date NOT NULL,
  `Customer_Reference` varchar(20) NOT NULL,
  `paymentermes` int(20) NOT NULL,
  `invoice_lines` varchar(20) NOT NULL,
  `salesperson` varchar(30) NOT NULL,
  `payment_type` int(18) NOT NULL,
  `due_date` date NOT NULL,
  `ordertype_custsupplyer` varchar(80) NOT NULL,
  `supplier_id` int(20) NOT NULL,
  PRIMARY KEY (`sales_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `customer id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesorders`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesreturn_orders`
--

CREATE TABLE IF NOT EXISTS `salesreturn_orders` (
  `Sales_return_order_id` int(20) NOT NULL AUTO_INCREMENT,
  `customer_id` int(20) NOT NULL,
  `employee_id` int(20) NOT NULL,
  `Customer` varchar(80) NOT NULL,
  `sales_Date_return_date` date NOT NULL,
  `Customer_Reference` varchar(20) NOT NULL,
  `paymentermes` int(18) NOT NULL,
  `invoice_lines` varchar(20) NOT NULL,
  `salesperson` varchar(18) NOT NULL,
  `payment_type` varchar(18) NOT NULL,
  `coustmer_reference` varchar(30) NOT NULL,
  `due_date` date NOT NULL,
  `ordertype_custsupplyer` varchar(80) NOT NULL,
  PRIMARY KEY (`Sales_return_order_id`),
  KEY `employee_id` (`employee_id`),
  KEY `customer_id` (`customer_id`,`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesreturn_orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `sales_particular`
--

CREATE TABLE IF NOT EXISTS `sales_particular` (
  `sales_id` int(10) NOT NULL,
  `pro_id` int(10) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `rate` int(20) NOT NULL,
  `amount` int(50) NOT NULL,
  KEY `sales_id` (`sales_id`),
  KEY `product_id` (`pro_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_particular`
--


-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `Supplier_id` int(20) NOT NULL AUTO_INCREMENT,
  `Product_Name` varchar(30) NOT NULL,
  `Name_company` varchar(40) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(60) NOT NULL,
  `Website` varchar(30) NOT NULL,
  `jobpositions` varchar(50) NOT NULL,
  `Mobile` int(50) NOT NULL,
  `Fax` int(18) NOT NULL,
  `E_mail` varchar(30) NOT NULL,
  `title` varchar(60) NOT NULL,
  PRIMARY KEY (`Supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `emp_pid` int(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  KEY `emp_id` (`emp_pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`emp_pid`, `user_name`, `password`) VALUES
(8, 'kaushik', '123');

-- --------------------------------------------------------

--
-- Table structure for table `warehousemanagement`
--

CREATE TABLE IF NOT EXISTS `warehousemanagement` (
  `wherehouse_id` int(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `Container_wise` varchar(500) NOT NULL,
  `Rack` varchar(500) NOT NULL,
  `Row` varchar(500) NOT NULL,
  `sales_in` varchar(100) NOT NULL,
  `sales_out` varchar(100) NOT NULL,
  `sales_return` varchar(100) NOT NULL,
  PRIMARY KEY (`wherehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `warehousemanagement`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `emp_official_information`
--
ALTER TABLE `emp_official_information`
  ADD CONSTRAINT `emp_official_information_ibfk_3` FOREIGN KEY (`emp_pid`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `emp_official_information_ibfk_4` FOREIGN KEY (`Department_id`) REFERENCES `department` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `finished_product`
--
ALTER TABLE `finished_product`
  ADD CONSTRAINT `finished_product_ibfk_1` FOREIGN KEY (`Category`) REFERENCES `finished_product_catagories` (`pro_cat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `finished_product_ibfk_2` FOREIGN KEY (`Product_type`) REFERENCES `finished_product_types` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `process_department`
--
ALTER TABLE `process_department`
  ADD CONSTRAINT `process_department_ibfk_12` FOREIGN KEY (`plant_id`) REFERENCES `plant_department` (`plant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `process_department_ibfk_15` FOREIGN KEY (`emp_pid`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `process_department_ibfk_16` FOREIGN KEY (`wherehouse_id`) REFERENCES `warehousemanagement` (`wherehouse_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`raw_material_id`) REFERENCES `rawmaterials` (`raw_material_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `quotations`
--
ALTER TABLE `quotations`
  ADD CONSTRAINT `quotations_ibfk_6` FOREIGN KEY (`salesperson`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quotations_ibfk_7` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quotations_ibfk_8` FOREIGN KEY (`employee_pid`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rawmaterials`
--
ALTER TABLE `rawmaterials`
  ADD CONSTRAINT `rawmaterials_ibfk_5` FOREIGN KEY (`Category_id`) REFERENCES `rawmaterialcatagories` (`Category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rawmaterials_ibfk_6` FOREIGN KEY (`type_id`) REFERENCES `rawmaterialsproduct_types` (`raw_material_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesorders`
--
ALTER TABLE `salesorders`
  ADD CONSTRAINT `salesorders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `salesorders_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`Supplier_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salesreturn_orders`
--
ALTER TABLE `salesreturn_orders`
  ADD CONSTRAINT `salesreturn_orders_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `salesreturn_orders_ibfk_4` FOREIGN KEY (`employee_id`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales_particular`
--
ALTER TABLE `sales_particular`
  ADD CONSTRAINT `sales_particular_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `salesorders` (`sales_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sales_particular_ibfk_2` FOREIGN KEY (`pro_id`) REFERENCES `finished_product` (`pro_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_info`
--
ALTER TABLE `user_info`
  ADD CONSTRAINT `user_info_ibfk_1` FOREIGN KEY (`emp_pid`) REFERENCES `emp_personal_information` (`emp_pid`) ON DELETE CASCADE ON UPDATE CASCADE;
