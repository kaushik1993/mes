<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from rawmaterialcatagories where Category_id=".$_REQUEST['Category_id'];
	if(mysqli_query($con,$str))
	{
		header ("location:rawmaterialcatagories.php");
	}
	
	?>
	