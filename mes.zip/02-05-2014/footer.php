			<div id="footer" style="height:90px; width:1200px; background-color: #6f7683;float:left; margin-top:-1px;  box-shadow: 1px -3px 1px white; z-index:3; position:relative;">
						<div id="block21" style="height:65px; width:300px;float:left; margin-top:15px; margin-left:5px;box-shadow:0px 2px 5px white;position:relative;border-radius: 5px 5px 5px 5px;"><h3>Copy Rights</h3></div>
					
					<div id="block7" style="height:65px; width:250px;float:right; margin-top:15px; margin-right:5px;">
						<div id="block21" class="footer">
						<img src="images/footer/twitter.png" height="30px" width="57px">
						</div>
						<div id="block21" class="footer">
						<img src="images/footer/facebook.png" height="30px" width="57px">
						</div>
						<div id="block21" class="footer">
						<img src="images/footer/google.png" height="30px" width="57px">
						</div>
						<div id="block21" class="footer">
						<img src="images/footer/yahoo.png" height="30px" width="57px">
						</div>
					</div>
			</div>
	
</div>
</center>
</strong>
</body>
</html>