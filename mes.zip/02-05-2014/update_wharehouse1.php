<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:100px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from warehousemanagement where wherehouse_id=".$_REQUEST['wherehouse_id']."";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:310px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:40px;">Update For Warehousemanagement</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">wherehouse_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="whare" value="<?php echo $row['wherehouse_id'];?>" required style="margin-left:5px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="descript" value="<?php echo $row['description'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Status :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="stat" value="<?php echo $row['Status'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Container_wise :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cont" value="<?php echo $row['Container_wise'];?>" required style="margin-left:5px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Rack :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="rac" value="<?php echo $row['Rack'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Row :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="ro" value="<?php echo $row['Row'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">sales_in :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sa" value="<?php echo $row['sales_in'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">sales_out :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sal" value="<?php echo $row['sales_out'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">sales_return :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sale" value="<?php echo $row['sales_return'];?>" required style="margin-left:25px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:130px; margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update warehousemanagement set description='" . $_POST["descript"] . "',Status='" . $_POST["stat"] . "',Container_wise='" . $_POST["cont"] . "',Rack='" . $_POST["rac"] . "',Row='" . $_POST["ro"] . "',sales_in='" . $_POST["sa"] ."',sales_out='" . $_POST["sal"] . "',sales_return='" . $_POST["sale"] ."' where wherehouse_id='".$_POST["whare"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:warehouse.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>