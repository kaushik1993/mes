
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from warehousemanagement where wherehouse_id=".$_REQUEST['wherehouse_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:warehouse.php");
	}
	
	?>