<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from emp_official_information";
    $resulta = mysqli_query($con,$qry); 
	$resultb = mysqli_query($con,$qry);   
   
?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:450px;width:800px;float:left;margin-top:50px;margin-left:100px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from emp_official_information where emp_pid='".$_REQUEST['emp_pid']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:365px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:80px;">Update For Emp Official</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="emp_pid" name="emp_pid">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['emp_pid'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Designation :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="Designation" name="Designation" value="<?php echo $row['Designation'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Department_id :
		</div>
		<div style="height:25px; width:300px; float:left; margin-left:-10px;">
			<select id="Department_id" name="Department_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['Department_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">basesalary :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="basesalary" name="basesalary" value="<?php echo $row['basesalary'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">ta :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="ta" name="ta" value="<?php echo $row['ta'];?>"required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">da :
		</div> 
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="da" name="da" value="<?php echo $row['da'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">hra :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="hra" name="hra" value="<?php echo $row['hra'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pf :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="pf" name="pf" value="<?php echo $row['pf'];?>" required style="margin-left:10px;"/>
		</div>
	</div><div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">grosssalary :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="grosssalary" name="grosssalary" value="<?php echo $row['grosssalary'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">JoiningDate :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="JoiningDate" name="JoiningDate" value="<?php echo $row['JoiningDate'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">workinghours :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="workinghours" name="workinghours" value="<?php echo $row['workinghours'];?>" required style="margin-left:10px;"/>
		</div>
	</div>

	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update emp_official_information set Designation='" . $_POST["Designation"] . "',Department_id=" . $_POST["Department_id"] . ",basesalary=" . $_POST["basesalary"] . ",ta=" . $_POST["ta"] . ",da=" . $_POST["da"] . ",hra=" . $_POST["hra"] .",pf=" . $_POST["pf"] . ",grosssalary=" . $_POST["grosssalary"] . ",joiningDate='" . $_POST["JoiningDate"] . "',workinghours=" . $_POST["workinghours"]." where emp_pid=".$_POST["emp_pid"]."";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:emp_official_information.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
		
<?php		
include('footer.php');
?>