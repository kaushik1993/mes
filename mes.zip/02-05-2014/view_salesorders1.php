<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1"><a href="salesorders.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:50px;margin-left:100px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from salesorders where sales_id='".$_REQUEST['sales_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
  ?>
<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">View For salesorders</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">sales_id
		</div>
		<div style="height:25px; width:300px;float:left;">
			<a href="invoice.php?sales_id=<?php echo $row['sales_id'];?>"><?php echo $row['sales_id']; ?></a>

		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">customer_id	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['customer_id'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Date_of_sales
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Date_of_sales'];?>
		</div>
	</div>

	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Customer_Reference
		</div>
		<div style="height:25px; width:300px; float:left;">
			 <?php echo $row['Customer_Reference'];?>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">paymentermes
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['paymentermes'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">invoice_lines
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['invoice_lines'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">salesperson	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['salesperson'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['payment_type'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['due_date'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">ordertype_custsupplyer		
		</div>
		<div style="height:25px; width:250px; float:left;">
			<?php echo $row['ordertype_custsupplyer'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">supplier_id
		</div>
		<div style="height:25px; width:250px; float:left;">
			<?php echo $row['supplier_id'];?>
		</div>
	</div>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>