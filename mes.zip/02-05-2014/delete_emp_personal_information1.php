<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$str= "delete from emp_personal_information where emp_pid=".$_REQUEST['emp_pid'];
	if(mysqli_query($con,$str))
	{
		header ("location:emp_personal_information.php");
	}
	
	?>
	