<div id="conten" style="height:800px; width:1200px; margin-top:-1px;">
			<div id="sidebar" style="height: 800px; width:190px; background-color:#324452; float:left; margin-top:-2px;">
				<div id="search" style="height:40px; width:190px; background-color: #cccccc; float:left; margin-right:5px;argin-top:1px;margin-bottom:1px;background-image:url(images/side.png);background-repeat:repeat-x; font-size:24px; font-family:Calibri; padding-top:3px; color:#004080;">
					Navigation			
				</div>
				<div id="customer" class="sidemenu">
					<div id="block1" class="sidemenu1" style="height:20px; width:30px">
						<img src="images/shortcute1/customer.png" height="20px" width="30px";>
					</div>
					<div id="blocka" class="sidemenu2" style="height:20px; width:140px">Customer</div>
				</div>
				<div id="hide"  class="box">
					<div id="hide"  class="box1"><a href="I_customer.php">Customer</a>
					</div>					
					<div id="hide"  class="box1"><a href="Customer.php">VIEW</a>
					</div>
				</div>
				<div id="quatation" class="sidemenu">
					<div id="block2"  class="sidemenu1">
						<img src="images/shortcute1/quatation.png" height="20px" width="30px";>
					</div>
					<div id="blockb" class="sidemenu2">Quatation</div>
					</div>
				<div id="hide1"  class="box">
						<div id="hide"  class="box1"><a href="I_quotations.php">Quatation</a>
						</div>
						<div id="hide"  class="box1"><a href="quotations.php">VIEW</a>
						</div>
					</div>
				<div id="purchase" class="sidemenu">
					<div id="block3"  class="sidemenu1">
						<img src="images/shortcute1/purchase.png" height="20px" width="30px";>
					</div>
					<div id="blockc" class="sidemenu2">Purchase</div>
				</div>
				<div id="hide2"class="box">
						<div id="hide"  class="box1"><a href="I_purchases.php">Purchase</a>
						</div>
						<div id="hide"  class="box1"><a href="purchases.php">VIEW</a>
						</div>
						</div>
				<div id="rawmaterial" class="sidemenu">
					<div id="block4"  class="sidemenu1">
						<img src="images/shortcute1/row.png" height="20px" width="30px";>
					</div>
					<div id="blockd" class="sidemenu2">Raw-Material</div>
				</div> 
				<div id="hide3"class="box3">
						<div id="hide"  class="box1"><a href="I_rawmaterialsproduct_types.php">product_types</a>
						</div>
						<div id="hide"  class="box1"><a href="rawmaterialsproduct_types.php">VIEW</a>
						</div>
						<div id="hide"  class="box1"><a href="I_rawmaterialcatagories.php">rawmaterialcatagories</a>
						</div>
						<div id="hide"  class="box1"><a href="rawmaterialcatagories.php">VIEW</a>
						</div>
						<div id="hide"  class="box1"><a href="I_rawmaterials.php">rawmaterials</a>
						</div>
						<div id="hide"  class="box1"><a href="rawmaterials.php">VIEW</a>
						</div>
					</div>
				<div id="warehouse" class="sidemenu">
					<div id="block5"  class="sidemenu1">
					<img src="images/shortcute1/warehouse.png" height="20px" width="30px";>
					</div>
					<div id="blocke" class="sidemenu2">Warehouse</div>
					</div>
				<div id="hide4"class="box">
						<div id="hide"  class="box1"><a href="I_warehouse.php">warehouse</a>
						</div>
						<div id="hide"  class="box1"><a href="warehouse.php">VIEW</a>
						</div>
					</div>
				<div id="plant" class="sidemenu">
					<div id="block6"  class="sidemenu1">
						<img src="images/shortcute1/plant.png" height="20px" width="30px";>
					</div>
					<div id="blockf" class="sidemenu2">Plant</div>
				</div>
				<div id="hide5"class="box">
						<div id="hide"  class="box1"><a href="I_plant_department.php">plant_department</a>
						</div>
						<div id="hide"  class="box1"><a href="plant_department.php">VIEW</a>
						</div>
					</div>
					<div id="department" class="sidemenu">
					<div id="block4"  class="sidemenu1">
						<img src="images/shortcute1/row.png" height="20px" width="30px";>
					</div>
					<div id="blockd" class="sidemenu2">Department</div>
				</div> 
				<div id="hide6"class="box">
				<div id="hide"  class="box1"><a href="I_department.php">department</a>
						</div>
						<div id="hide"  class="box1"><a href="Department.php">VIEW</a>
						</div>						
				</div>
				<div id="process" class="sidemenu">
				<div id="block7"  class="sidemenu1">
					<img src="images/shortcute1/process.gif" height="20px" width="30px";>
					</div>
					<div id="blockg" class="sidemenu2">Process</div>
				</div>
				<div id="hide7"class="box">
						<div id="hide"  class="box1"><a href="I_process_department.php">process_department</a>
						</div>
						<div id="hide"  class="box1"><a  href="process_department.php">VIEW</a>
						</div>
					</div>
				<div id="finished_product" class="sidemenu">
				<div id="block7"  class="sidemenu1">
					<img src="images/shortcute1/product.png" height="20px" width="30px";>
					</div>
					<div id="blockg" class="sidemenu2">finished_product</div>
				</div>
				<div id="hide8"class="box3">
						<div id="hide"  class="box1"><a href="I_finished_product_catagories.php">finished_product_catagories</a>
						</div>
						<div id="hide"  class="box1"><a href="finished_product_catagories.php">VIEW</a>
						</div>
						<div id="hide"  class="box1"><a href="I_finished_product_types.php">finished_product_types</a>
						</div>
						<div id="hide"  class="box1"><a href="finished_product_types.php">VIEW</a>
						</div>
						<div id="hide"  class="box1"><a href="I_finished_product.php">finished_products</a>
						</div>
						<div id="hide"  class="box1"><a href="finished_product.php">VIEW</a>
						</div>
					</div>
				<div id="employee" class="sidemenu">
					<div id="block8" class="sidemenu1">
						<img src="images/shortcute1/employee.png" height="20px" width="30px";>
					</div>
					<div id="blockh" class="sidemenu2">Employee</div>
				</div>
				<div id="hide9"class="box2">
						<div id="hide"  class="box1"><a href="I_emp_official.php">emp_official</a>
						</div>
						<div id="hide"  class="box1"><a href="emp_official_information.php">VIEW</a>
						</div>
						<div id="hide"  class="box1"><a href="I_emp_personal.php">emp_personal</a>
						</div>
						<div id="hide"  class="box1"><a href="emp_personal_information.php">VIEW</a>
						</div>
					</div>
				<div id="supplier" class="sidemenu">
					<div id="block9" class="sidemenu1">
					<img src="images/shortcute1/supplier.png" height="20px" width="30px";>
					</div>
					<div id="blocki" class="sidemenu2">Supplier</div>
				</div>
				<div id="hide10"class="box">
						<div id="hide"  class="box1"><a href="I_Supplier.php">Supplier</a>
						</div>
						<div id="hide"  class="box1"><a href="supplier.php">VIEW</a>
						</div>
					</div>
				<div id="salesorder" class="sidemenu">
					<div id="block10" class="sidemenu1">
					<img src="images/shortcute1/salesorder.png" height="20px" width="30px";>
					</div>
					<div id="blockj" class="sidemenu2">Sales Order</div>
				</div>
				<div id="hide11"class="box">
						<div id="hide"  class="box1"><a href="I_salesorders.php">salesorders</a>
						</div>
						<div id="hide"  class="box1"><a href="salesorders.php">VIEW</a>
						</div>
					</div>
				<div id="salesorderreturn" class="sidemenu">
					<div id="block11" class="sidemenu1">
					<img src="images/shortcute1/salesorderreturn.png" height="20px" width="30px";>
					</div>
					<div id="blockk"  class="sidemenu2">Salesorder Return</div>
				</div>
				<div id="hide12"class="box">
						<div id="hide"  class="box1"><a href="I_salesreturn.php">salesreturn</a>
						</div>
						<div id="hide"  class="box1"><a href="salesreturn_orders.php">VIEW</a>
						</div>
					</div>
				<div id="contect" class="sidemenu">
					<div id="block12" class="sidemenu1">
					<img src="images/shortcute1/contect.png" height="20px" width="30px";>
					</div>
					<div id="blockl" class="sidemenu2">User</div>
				</div>
				<div id="hide13" class="box4">
						<div id="hide"  class="box1"><a href="I_user_info.php">user_information</a>
						</div>
						<div id="hide"  class="box1"><a href="settingpass.php">change_password</a>
						</div>
						<div id="hide"  class="box1"><a href="user_info.php">VIEW</a>
						</div>

					</div>
					
			</div>
			
			
			<div id="main2" style="height:800px; width:1000px;float:left; margin-top:-1px;">
				<div id="block20" style="height:100px; width:1004px; background-color:#cddceb; float:left; margin-top:-1px; margin-left:5px;">
					<div id="dashboard" class="shortbox">
						<div id="block13" class="shortcut"><a href="main.php" style="text-decoration:none;color:#004080;">Dashboard</a></div>
						<div id="block13_1" class="shortcut1">
						<img src="images/quickshortcute/dashboard.png" height="40px" width="60px"; style="margin-top:10px;">
						</div>	
					</div>
					<div id="sales" class="shortbox">
						<div id="block14"  class="shortcut"><a href="salesorders.php" style="text-decoration:none;color:#004080;">Sales</a></div>
						<div id="block14_1" class="shortcut1">
						<img src="images/quickshortcute/sales.png" height="40px" width="60px"; style="margin-top:10px;">
						</div>
					</div>
					<div id="purchase" class="shortbox">
						<div id="block15"  class="shortcut"><a href="purchases.php"  style="text-decoration:none;color:#004080;">Purchase</a></div>
						<div id="block15_1" class="shortcut1">
						<img src="images/quickshortcute/purchase.png" height="40px" width="60px"; style="margin-top:10px;">
						</div>
					</div>
					<div id="rowmaterial" class="shortbox">
							<div id="block16"  class="shortcut"><a href="rawmaterials.php"  style="text-decoration:none;color:#004080;">Rowmaterial</a></div>
							<div id="block16_1" class="shortcut1">
							<img src="images/quickshortcute/row.png" height="40px" width="60px"; style="margin-top:10px;">
							</div>
					</div>
					<div id="plant" class="shortbox">
							<div id="block17"  class="shortcut"><a href="plant_department.php"  style="text-decoration:none;color:#004080;">Plant</a></div>
							<div id="block17_1" class="shortcut1">
							<img src="images/quickshortcute/plant.png" height="40px" width="60px"; style="margin-top:10px;">
							</div>
					</div>
					<div id="product" class="shortbox">
							<div id="block18"  class="shortcut"><a href="finished_product_catagories.php"  style="text-decoration:none;color:#004080;">Product</a></div>
							<div id="block18_1" class="shortcut1">
							<img src="images/quickshortcute/product.png" height="40px" width="60px"; style="margin-top:10px;">
							</div>
					</div>
					<div id="warehouse" class="shortbox">
							<div id="block19"  class="shortcut"><a href="warehouse.php"  style="text-decoration:none;color:#004080;">Warehouse</a></div>
							<div id="block19_1" class="shortcut1">
							<img src="images/quickshortcute/warehouse.png" height="40px" width="60px"; style="margin-top:10px;">
							</div>
					</div>
					<div id="supplier" class="shortbox">
							<div id="block20"  class="shortcut"><a href="supplier.php"  style="text-decoration:none;color:#004080;">Supplier</a></div>
							<div id="block20_1" class="shortcut1">
							<img src="images/quickshortcute/supplier.png" height="40px" width="60px"; style="margin-top:10px;">
							</div>
				</div>
			</div>
	