
<?php
	$con= mysqli_connect("localhost","root","","mes") or die ("unble to connect");
	$qry= "delete from salesorders where sales_id=".$_REQUEST['sales_id']."";
	if(mysqli_query($con,$qry))
	{
		header ("location:salesorders.php");
	}
	
	?>
