<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:50px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from supplier where Supplier_id='".$_REQUEST['Supplier_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:500px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">Update For Supplier</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Supplier_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" value="<?php echo $row['Supplier_id'];?>" name="supp" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">Product_Name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['Product_Name'];?>" name="prod"style="margin-left:-20px;" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left;text-align:justify;">Name_company :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['Name_company'];?>" name="name" style="margin-left:-40px;" required/>
		</div>
	</div>
	<div style="height:80px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:88px; width:300px; float:left; margin-top:5px;">
			<textarea  name="add" rows="4" value="<?php echo $row['Address'];?>" cols="17" required></textarea>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">City :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['City'];?>" name="cit" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['State'];?>" name="stat" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Website :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['Website'];?>" name="Webs" required/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">jobpositions :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['jobpositions'];?>" name="jobpos" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Mobile :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['Mobile'];?>" name="Mobil" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Fax :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['Fax'];?>" name="fa" required />
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['E_mail'];?>" name="mail" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">title :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" value="<?php echo $row['title'];?>" name="tit" required/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update supplier set Product_Name='" . $_POST["prod"] . "',Name_company='" . $_POST["name"] . "',Address='" . $_POST["add"] . "',City='" . $_POST["cit"] . "',State='" . $_POST["stat"] . "',Website='" . $_POST["Webs"] ."',jobpositions='" . $_POST["jobpos"] . "',Mobile='" . $_POST["Mobil"] . "',Fax='" . $_POST["fa"] . "',E_mail='" . $_POST["mail"] ."',title='" . $_POST["tit"].
	"' where Supplier_id='".$_POST["supp"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:supplier.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>