<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1"><a href="emp_personal_information.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from emp_personal_information where emp_pid='".$_REQUEST['emp_pid']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:580px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:80px;">views For emp_personal</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['emp_pid'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">first_name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['first_name'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">last_name
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['last_name'];?>
		</div>
	</div>
	<div style="height:72px; width:800px; float:left;margin-left:150px;">
		<div style="height:60px; width:100px; float:left;margin-top:25px;text-align:justify;">Address
		</div>
		<div style="height:70px; width:300px; float:left;">
			<?php echo $row['Address'];?>
			
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">contact
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['contact'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['E_mail'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">dateofbirth
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['dateofbirth'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">city
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['city'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['State'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">country
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['country'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">blodgroup
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['blodgroup'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">gender
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="radio" id="radio" name="mal" />male
			<input type="radio" id="radio" name="femal"/>female
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">adharcardno
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['adharcardno'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pancardno
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['pancardno'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">qualification
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['qualification'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Expiriance
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Expiriance'];?>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">images
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['image'];?>
		</div>
	</div>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>