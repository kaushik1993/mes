<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1"><a href="purchases.php" style="float:left; margin-left:5px;">Back</a>
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from purchases where purch_id='".$_REQUEST['purch_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:380px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">View For purchases</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">purch_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['purch_id'];?>
		</div>
	</div>
    <div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">raw_material_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['raw_material_id'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">dealer
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['dealer'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">date_of_purchase
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['date_of_purchase'];?> 
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">paymentermes	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['paymentermes'];?>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type		
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['payment_type'];?> 
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['due_date'];?> 
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Sale_price
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Sale_price'];?> 
		</div>
	</div>
	
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Cost_Price
		</div>
		<div style="height:25px; width:300px; float:left;">
			<?php echo $row['Cost_Price'];?> 
		</div>
	</div>

</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>