<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:400px;width:1000px;float:left;margin-top:100px;margin-left:10px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px; overflow: auto;">
						<div style="height:30px; width:1000px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	                       <font size="+2" color="white">All process_department information</font>
                    <a href="I_process_department.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from process_department";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:1000px;float:left;">';
	echo'<div style="height:20px; width:1000px; color:white;">
			<div style="height:20px; width:50px; float:left; background:#00458f;">pro_id
			</div>
			<div style="height:20px; width:50px; float:left; background:#00458f;">emp_id	
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">plant_id
			</div>
			<div style="height:20px; width:55px; float:left; background:#00458f;">ware_id
			</div>
			<div style="height:20px; width:100px; float:left; background:#00458f;">start_date
			</div>
			<div style="height:20px; width:90px; float:left; background:#00458f;">due_date
			</div>
			<div style="height:20px; width:110px; float:left; background:#00458f;">finished_date
			</div>
			<div style="height:20px; width:50px; float:left; background:#00458f;">status
			</div>
			<div style="height:20px; width:195px; float:left; background:#00458f;">work_status
			</div>
			<div style="height:20px; width:90px; float:left; background:#00458f;">description
			</div>
			<div style="height:20px; width:50px; float:left; background:#00458f;">DELETE
			</div>
			<div style="height:20px; width:50px; float:left; background:#00458f;">UPDATE
			</div>
			<div style="height:20px; width:40px; float:left; background:#00458f;">VIEW
			</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:1000px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:1000px; background:silver;">';
			$cnt=0;
		}
		
			echo'<div style="height:20px; width:50px; float:left;"><a href="view_process_department1.php?process_id='.$arr['process_id'].'">'.$arr['process_id'].'</a>
				</div>
				<div style="height:20px; width:50px; float:left;"><a href="view_emp_personal_information1.php?emp_pid='.$arr['emp_pid'].'">'.$arr['emp_pid'].'</a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="view_plant_department1.php?plant_id='.$arr['plant_id'].'">'.$arr['plant_id'].'</a>
				</div>
				<div style="height:20px; width:55px; float:left;"><a href="view_wharehouse1.php?wherehouse_id='.$arr['wherehouse_id'].'">'.$arr['wherehouse_id'].'</a>
				</div>
				<div style="height:20px; width:100px; float:left;">'.$arr['start_date'].'
				</div>
				<div style="height:20px; width:90px; float:left;">'.$arr['due_date'].'
				</div>
				<div style="height:20px; width:110px; float:left;">'.$arr['finished_date'].'
				</div>
				<div style="height:20px; width:50px; float:left;">'.$arr['status'].'
				</div>
				<div style="height:20px; width:195px; float:left;">
                <progress value="'.$arr['work_status'].'" max="100" style=""></progress>'.$arr['work_status'].'%
				</div>
				<div style="height:20px; width:90px; float:left;">'.$arr['description'].'
				</div>
				<div style="height:20px; width:50px; float:left;"><a href="delete_process_department.php?process_id='.$arr['process_id'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:50px; float:left;"><a href="update_process_department1.php?process_id='.$arr['process_id'].'"><img src="images/update.png" height="19px"/></a></div>
				<div style="height:20px; width:40px; float:left;"><a href="view_process_department1.php?process_id='.$arr['process_id'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>