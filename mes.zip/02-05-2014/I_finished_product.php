<?php
include('head.php');
include('sidemenu.php');

?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from finished_product_catagories";
    $resulta = mysqli_query($con,$qry);
   	$qry1="Select * from finished_product_types";
    $resultb = mysqli_query($con,$qry1);
    
   
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:800px;float:left;margin-top:105px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;" >
<form name="regi" method="post">
<div style="height:210px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2"style="text-shadow: 1px 2px 2px white;">finished_product Form</font>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pro_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pro" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="na" style=" margin-left:70px;"required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Category :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Category" name="Category">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['pro_cat_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select> 
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Product_type :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="Product_type" name="Product_type">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['type_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select> 
		</div>
	</div>
	<div style="height:25px; width:800px; float:left; margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="descript" style=" margin-left:70px;"required/>
		</div>
	</div>
	
	<input type="submit" name="sbt" value="Submit" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />

</div>
</form>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql = "insert into finished_product(pro_id,name,Category,Product_type,description) values('".$_POST['pro']."','".$_POST['na']."','".$_POST['Category']."','".$_POST['Product_type']."','".$_POST['descript']."')";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:finished_product.php");
	
	mysqli_close($con);	
}
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>