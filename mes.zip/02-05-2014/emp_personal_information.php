<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
					
						<div style="height:30px; width:900px; float:left;margin-top:100px;margin-left:90px; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	                       <font size="+2" color="white">All emp_personal_information</font>
                    <a  href="I_emp_personal.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>
					<div id="block32" style="font-family:Calibri;height:400px;width:900px;float:left;margin-left:90px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;
                    ">
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from emp_personal_information";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:900px;">';
	echo'<div style="height:20px; width:900px; color:white;">
			<div style="height:20px; width:80px; float:left; background:#00458f;">emp_pid
			</div>
			<div style="height:20px; width:120px; float:left; background:#00458f;">first_name	
			</div>
			<div style="height:20px; width:150px; float:left; background:#00458f;">Address
			</div>
			<div style="height:20px; width:170px; float:left; background:#00458f;">E_mail
			</div>
			<div style="height:20px; width:90px; float:left; background:#00458f;">dateofbirth
			</div>
			<div style="height:20px; width:80px; float:left; background:#00458f;">gender
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">DELETE
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">UPDATE
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">VIEW
			</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:900px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:900px; background:silver;">';
			$cnt=0;
		}
		
			echo'<div style="height:20px; width:80px; float:left;">'.$arr['emp_pid'].'
				</div>
				<div style="height:20px; width:120px; float:left;">'.$arr['first_name'].'
				</div>
				<div style="height:20px; width:150px; float:left;">'.$arr['Address'].'
				</div>
				<div style="height:20px; width:170px; float:left;">'.$arr['E_mail'].'
				</div>
				<div style="height:20px; width:90px; float:left;">'.$arr['dateofbirth'].'
				</div>
				<div style="height:20px; width:80px; float:left;">'.$arr['gender'].'
				</div>
				
				<div style="height:20px; width:70px; float:left;"><a href="delete_emp_personal_information1.php?emp_pid='.$arr['emp_pid'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="update_emp_personal_information1.php?emp_pid='.$arr['emp_pid'].'"><img src="images/update.png"/></a></div>
				<div style="height:20px; width:70px; float:left;"><a href="view_emp_personal_information1.php?emp_pid='.$arr['emp_pid'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>



</div>
</div>
</div>
<?php		
include('footer.php');
?>