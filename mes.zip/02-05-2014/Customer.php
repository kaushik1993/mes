<?php
include('head.php');
include('sidemenu.php');
?>
				
				<div id="block30" class="overview1">
			
					<div id="block32" style="font-family:Calibri;height:400px;width:1000px;float:left;margin-top:100px;margin-left:5px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<div style="height:30px; width:1000px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" color="white">All Customer information</font>
	
				<a href="I_customer.php" style="float:left; margin-left:20px:; color:#FFFFFF">INSERT</a></div>
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from customer";
	$result=mysqli_query($con,$qry);
	
echo '<div style="height:20px; width:1000px; float:left">';
	echo'<div style="height:20px; width:1000px; color:white;">
			<div style="height:20px; width:100px; float:left; background:#015A9F;">customer_id
			</div>
			<div style="height:20px; width:100px; float:left; background:#015A9F;">Nameofcust
			</div>
			<div style="height:20px; width:140px; float:left; background:#015A9F;">Address
			</div>
			<div style="height:20px; width:100px; float:left; background:#015A9F;">State
			</div>
			<div style="height:20px; width:100px; float:left; background:#015A9F;">country
			</div>
			<div style="height:20px; width:100px; float:left; background:#015A9F;">Mobile
			</div>
			<div style="height:20px; width:110px; float:left; background:#015A9F;">E_mail
			</div>
			<div style="height:20px; width:80px; float:left; background:#015A9F;">DELETE
			</div>	
			<div style="height:20px; width:80px; float:left; background:#015A9F;">UPDATE
			</div>
			<div style="height:20px; width:90px; float:left; background:#015A9F;">VIEW
			</div>		
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:1000px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:1000px;background:silver;">';	
			$cnt=0;
		}
			echo'<div style="height:20px; width:100px; float:left;">'.$arr['customer_id'].'
			</div>
			<div style="height:20px; width:100px; float:left;">'.$arr['Nameofcust'].'
			</div>
			<div style="height:20px; width:140px; float:left;">'.$arr['Address'].'
			</div>
			<div style="height:20px; width:100px; float:left;">'.$arr['State'].'
			</div>
			<div style="height:20px; width:100px; float:left;">'.$arr['country'].'
			</div>
			<div style="height:20px; width:100px; float:left;">'.$arr['Mobile'].'
			</div>
			<div style="height:20px; width:110px; float:left;">'.$arr['E_mail'].'
			</div>
			<div style="height:20px; width:80px; float:left;"><a href="delete_customer.php?customer_id='.$arr['customer_id'].'"><img src="images/delete.png"/></a>
			</div>
			<div style="height:20px; width:80px; float:left;"><a href="update_customer1.php?customer_id='.$arr['customer_id'].'"><img src="images/update.png"/></a></div>
			<div style="height:20px; width:90px; float:left;"><a href="view_customer1.php?customer_id='.$arr['customer_id'].'">VIEW</a></div>

	</div>';
}
echo'</div>';
?>
</div>
</form>
</div>
</div>
</div>
		
<?php		
include('footer.php');
?>