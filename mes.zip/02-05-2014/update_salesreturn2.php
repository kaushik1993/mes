<?php
include('head.php');
include('sidemenu.php');
?>
<?php
    $con=mysqli_connect("localhost","root","","mes");
     // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
                
	$qry="Select * from salesreturn_orders";
    $resulta = mysqli_query($con,$qry);
	$resultb = mysqli_query($con,$qry);
?>

				
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:500px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from salesreturn_orders where Sales_return_order_id='".$_REQUEST['Sales_return_order_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post">
<div style="height:445px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">Update For Salesreturn</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Sales_return_order_id
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="Sales_return_order_id" value="<?php echo $row['Sales_return_order_id'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">customer_id
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="customer_id" name="customer_id">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['customer_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">employee_id	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<select id="employee_id" name="employee_id">
                 <?php
                while($row100=mysqli_fetch_array($resultb))
                {
                    echo '<option>';
                    $ei = $row100['employee_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Customer
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cust" value="<?php echo $row['Customer'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">sales_Date_return_date	
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="sle" value="<?php echo $row['sales_Date_return_date'];?>" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Customer_Reference
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="custo" value="<?php echo $row['Customer_Reference'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
		<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">paymentermes
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="paym" value="<?php echo $row['paymentermes'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">invoice_lines
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="inv" value="<?php echo $row['invoice_lines'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">salesperson
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sales" value="<?php echo $row['salesperson'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;">payment_type
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pay" value="<?php echo $row['payment_type'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">coustmer_reference
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="cou" value="<?php echo $row['coustmer_reference'];?>" required/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="due" value="<?php echo $row['due_date'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:150px; float:left;text-align:justify;">ordertype_custsupplyer	
		</div>
		<div style="height:25px; width:250px; float:left;">
			<input type="text" id="text" name="ord" value="<?php echo $row['ordertype_custsupplyer'];?>" required/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:100px; margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update salesreturn_orders set customer_id='" .$_POST["customer_id"]. "',employee_id='" . $_POST["employee_id"] . "',Customer='" . $_POST["cust"] . "',sales_Date_return_date='" . $_POST["sle"] . "',Customer_Reference='" . $_POST["custo"] . "',paymentermes='" . $_POST["paym"] ."',invoice_lines='" . $_POST["inv"] . "',salesperson='" . $_POST["sales"] . "',payment_type='" . $_POST["pay"]. "',coustmer_reference='" . $_POST["cou"]. "',due_date='" . $_POST["due"]. "',ordertype_custsupplyer='" . $_POST["ord"]."' where Sales_return_order_id='".$_POST["Sales_return_order_id"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:salesreturn_orders.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>