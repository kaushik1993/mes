<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:250px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from rawmaterialsproduct_types where raw_material_id='".$_REQUEST['raw_material_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
 <form name="regi" method="post">
<div style="height:250px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:50px;">Update For rawmaterialsproduct_types</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left;text-align:justify;">raw_material_id :
		</div>
		<div style="height:25px; width:300px;float:left;">
			<input type="text" id="text" name="raw" value="<?php echo $row['raw_material_id'];?>" required style="margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">type_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="typ" value="<?php echo $row['type_name'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">creation_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="cre" value="<?php echo $row['creation_date'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Description :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="des" value="<?php echo $row['Description'];?>" required style="margin-left:50px;"/>
		</div>
	</div>
	
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-left:100px; margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update rawmaterialsproduct_types set type_name='" . $_POST["typ"] . "',creation_date='" . $_POST["cre"] . "',Description='" . $_POST["des"] 
	."' where raw_material_id='".$_POST["raw"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:rawmaterialsproduct_types.php");
	
	mysqli_close($con);
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>