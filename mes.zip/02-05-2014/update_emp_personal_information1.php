<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:580px;width:800px;float:left;margin-top:5px;margin-left:80px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from emp_personal_information where emp_pid='".$_REQUEST['emp_pid']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
?>
<form name="regi" method="post" enctype="multipart/form-data">
<div style="height:580px; width:800px;">
	<div style="height:50px; width:800px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+3" style="margin-left:80px;">Update For emp_personal</font>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">emp_pid :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="emp_pid" value="<?php echo $row['emp_pid'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">first_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="first_name" value="<?php echo $row['first_name'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">last_name :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="last_name" value="<?php echo $row['last_name'];?>" required=""/>
		</div>
	</div>
	<div style="height:72px; width:800px; float:left;margin-left:150px;">
		<div style="height:60px; width:100px; float:left;margin-top:25px;text-align:justify;">Address :
		</div>
		<div style="height:70px; width:300px; float:left;">
			<textarea  name="Address" rows="3" cols="17" value="<?php echo $row['Address'];?>" style="height:70px; margin-top:2px;" required=""></textarea>
			
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">contact :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="contact" value="<?php echo $row['contact'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">E_mail :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="E_mail" value="<?php echo $row['E_mail'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">dateofbirth :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type= "date" id="text" name="dateofbirth" value="<?php echo $row['dateofbirth'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">city :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="city" value="<?php echo $row['city'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">State :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="state" value="<?php echo $row['State'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">country :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="country" value="<?php echo $row['country'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">blodgroup :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="blodgroup" value="<?php echo $row['blodgroup'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">gender :
		</div>
		<div style="height:25px; width:300px; float:left;">
			 <input type="radio" name="gender" value="female" required>Female
  			 <input type="radio" name="gender" value="male" required>Male
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">adharcardno :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="adharcardno" value="<?php echo $row['adharcardno'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">pancardno :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pancardno" value="<?php echo $row['pancardno'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">qualification :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="qualification" value="<?php echo $row['qualification'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Expiriance :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="Expiriance" value="<?php echo $row['Expiriance'];?>" required=""/>
		</div>
	</div>
	<div style="height:25px; width:800px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">images :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="file" name="file" value="file" required/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="update" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
</div>
</form>
</div>
</div>
</div>
		
<?php		
include('footer.php');
?>
<?php
$con=mysqli_connect("localhost","root","","mes") or die("unable to connect");



function create_guid($namespace = 'www.ddl.com'){     
    static $guid = '';
    $uid = uniqid("", true);
    $data = $namespace;
    $data .= $_SERVER['REQUEST_TIME'];
    $data .= $_SERVER['HTTP_USER_AGENT'];
    $data .= $_SERVER['REMOTE_ADDR'];
    $data .= $_SERVER['REMOTE_PORT'];
    $hash = strtoupper(hash('ripemd128', $uid . $guid . md5($data)));
    $guid = substr($hash,  0,  8) . 
            substr($hash,  8,  4) .
            substr($hash, 12,  4) .
            substr($hash, 16,  4) .
            substr($hash, 20, 12);
    return $guid;
  }
  

if(isset($_POST['sbt']))
	{
	$id = $_FILES['file']['name'];
	$type=$_FILES['file']['type'];
	$data = $_FILES['file']['tmp_name'];
	$random = create_guid();
	
	$ext=end(explode(".",$id));
	$path= "images/".$random.".".$ext;

$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update emp_personal_information set first_name='" . $_POST["first_name"] . "',last_name='" . $_POST["last_name"] . "',Address='" . $_POST["Address"] . "',contact='" . $_POST["contact"] . "',E_mail='" . $_POST["E_mail"] . "',dateofbirth='" . $_POST["dateofbirth"] . "',qualification='" . $_POST["qualification"] ."',city='" . $_POST["city"] . "',state='" . $_POST["state"] . "',country='" . $_POST["country"] . "',blodgroup='" . $_POST["blodgroup"]. "',adharcardno='" . $_POST["adharcardno"] ."',gender='" . $_POST["gender"] ."',pancardno='" . $_POST["pancardno"] . "',qualification='" . $_POST["qualification"] . "',Expiriance='" . $_POST["Expiriance"] ."',image='".$path."' where emp_pid='".$_POST["emp_pid"]."'";		
move_uploaded_file($_FILES['file']['tmp_name'],$path);		
	echo $sql;
mysqli_query($con,$sql);	
   
		header("location:emp_personal_information.php");
		
	}

?>
