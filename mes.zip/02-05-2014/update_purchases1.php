<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:380px;width:700px;float:left;margin-top:80px;margin-left:150px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
<?php
	$con = mysqli_connect("localhost","root","","mes") or die("could not connect to server");	
	$qry ="select * from purchases where purch_id='".$_REQUEST['purch_id']."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
    $qry="Select * from rawmaterials";
    $resulta = mysqli_query($con,$qry);
?>
<form name="regi" method="post">
<div style="height:380px; width:700px;">
	<div style="height:50px; width:700px; float:left;background-repeat:repeat-x;background-image:url(images/header1.png);"><font size="+2" style="margin-left:80px;">Update For purchases</font>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">purch_id :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="prur"  value="<?php echo $row['purch_id'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
    <div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:120px; float:left;text-align:justify;">raw_material_id  :
		</div>
		<div style="height:25px; width:310px; float:left;">
			<select id="raw_material_id" name="raw_material_id" style=" margin-left:-30px;">
                 <?php
                while($row100=mysqli_fetch_array($resulta))
                {
                    echo '<option>';
                    $ei = $row100['raw_material_id'];
                    echo $ei;
                    echo '</option>';
                }
                ?>
                
            </select>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">dealer :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="deal" value="<?php echo $row['dealer'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:130px; float:left;text-align:justify;">date_of_purchase :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="da" value="<?php echo $row['date_of_purchase'];?>" required style=" margin-left:10px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:110px; float:left;text-align:justify;">paymentermes :	
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="pay" value="<?php echo $row['paymentermes'];?>" required style=" margin-left:50px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">payment_type :		
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="paym" value="<?php echo $row['payment_type'];?>"required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">due_date :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="date" id="text" name="date" value="<?php echo $row['due_date'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Sale_price :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="sal" value="<?php echo $row['Sale_price'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	
	<div style="height:25px; width:700px; float:left;margin-left:150px;">
		<div style="height:25px; width:100px; float:left;text-align:justify;">Cost_Price :
		</div>
		<div style="height:25px; width:300px; float:left;">
			<input type="text" id="text" name="cos" value="<?php echo $row['Cost_Price'];?>" required style=" margin-left:70px;"/>
		</div>
	</div>
	<div>
	<input type="submit" name="sbt" value="UPDATE" style="margin-top:10px;" />
	<input type="reset" name="btnclear" value="Reset" />
	</div>
<?php
if(isset($_POST['sbt']))
{
	$con = mysqli_connect("localhost","root","","mes") or die("error: could not connect to server");	
	$sql="update purchases set raw_material_id='" . $_POST["raw_material_id"] . "',dealer='" . $_POST["deal"] . "',date_of_purchase='" . $_POST["da"] . "',paymentermes='" . $_POST["pay"] . "',payment_type='" . $_POST["paym"] . "',due_date='" . $_POST["date"] . "',Sale_price='" . $_POST["sal"] ."',Cost_Price='" . $_POST["cos"] ."' where purch_id='".$_POST["prur"]."'";	
if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
	header("location:purchases.php");
	
	mysqli_close($con);	
}
?>
</div>
</form>
</div>
</div>
</div>
<?php		
include('footer.php');
?>