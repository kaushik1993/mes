<?php
include('head.php');
include('sidemenu.php');
?>
				<div id="block30" class="overview1">
					<div id="block32" style="font-family:Calibri;height:400px;width:690px;float:left;margin-top:100px;margin-left:30px;box-shadow:0px 10px 50px #a5a3a4; position:relative;border-radius:5px 5px 5px 5px;">
						<div style="height:30px; width:690px; float:left; background-repeat:repeat-x;  background-image:url(images/header1.png);">
	<font size="+2" color="white">All finished_product information</font>
                    <a href="I_finished_product.php"style="float:left; margin-left:20px; color: white;">INSERT</a>
					</div>
<?php
	$con=mysqli_connect("localhost","root","","mes")or die("unable to connect");
	$qry="select * from finished_product";
	$result=mysqli_query($con,$qry);
echo '<div style="height:20px; width:690px; float:left;">';
	echo'<div style="height:20px; width:690px; color:white;">
			<div style="height:20px; width:100px; float:left; background:#00458f;">pro_id
			</div>
			<div style="height:20px; width:120px; float:left; background:#00458f;">name	
			</div>
			<div style="height:20px; width:120px; float:left; background:#00458f;">Category
			</div>
			<div style="height:20px; width:140px; float:left; background:#00458f;">Product_type
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">DELETE
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">UPDATE
			</div>
			<div style="height:20px; width:70px; float:left; background:#00458f;">VIEW
			</div>
	</div>';
	$cnt=0;
	while($arr=mysqli_fetch_array($result))
	{
		if($cnt==0)
		{
			echo'<div style="height:20px; width:690px; background:white;">';
		$cnt=1;
		}
		else
		{
			echo'<div style="height:20px; width:690px; background:silver;">';
			$cnt=0;
		}
		
			echo'<div style="height:20px; width:100px; float:left;">'.$arr['pro_id'].'
				</div>
				<div style="height:20px; width:120px; float:left;">'.$arr['name'].'
				</div>
				<div style="height:20px; width:120px; float:left;"><a href="view_finished_product3.php?pro_id='.$arr['pro_id'].'">'.$arr['Category'].'</a>
				</div>
				<div style="height:20px; width:140px; float:left;"><a href="view_finished_product3.php?pro_id='.$arr['pro_id'].'">'.$arr['Product_type'].'</a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="delete_finished_product.php?pro_id='.$arr['pro_id'].'"><img src="images/delete.png"/></a>
				</div>
				<div style="height:20px; width:70px; float:left;"><a href="update_finished_product3.php?pro_id='.$arr['pro_id'].'"><img src="images/update.png"/></a></div>
				<div style="height:20px; width:70px; float:left;"><a href="view_finished_product3.php?pro_id='.$arr['pro_id'].'">VIEW</a></div>
	</div>';
	}
echo'</div>';
?>

</div>
</div>
</div>
<?php		
include('footer.php');
?>